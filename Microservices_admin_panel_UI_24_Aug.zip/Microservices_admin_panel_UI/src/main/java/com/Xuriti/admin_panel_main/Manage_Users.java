package com.Xuriti.admin_panel_main;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Manage_Users {
WebDriver driver;
	
	
	public Manage_Users  (WebDriver driver) throws InterruptedException {
		this.driver = driver;
	
		//Click on Manage_Users
				 
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("/html/body/app-root/app-dashboard/app-layout/mat-sidenav-container/mat-sidenav/div/app-sidebar/div/div/div[3]/mat-nav-list/mat-list-item[4]/span/span[2]")).click(); 
					
	  
				 
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
				
}
public void Edit_user_Details() throws InterruptedException {
	
	//Click on Edit_Users
	 
	Thread.sleep(3000);
	
	driver.findElement(By.xpath("//*[@id=\"userlist-page\"]/div/table/tbody/tr[2]/td[6]/button/span[1]/mat-icon")).click(); 	
}
public void Edit_User_FN(String FN) throws InterruptedException {
	
	    //Edit user
		
	    Thread.sleep(3000);
	   

	    driver.findElement(By.id("mat-input-3")).clear();//FirstName
	    
	    driver.findElement(By.id("mat-input-3")).sendKeys(FN);//FirstName 
	    
	  //Submit
	    
	    driver.findElement(By.xpath("//*[@id=\"add-edit-user-dialog\"]/mat-dialog-content/div[2]/form/div[3]/div[1]/button/span[1]")).click(); //admin
	 
	    Thread.sleep(3000);
		
		if(driver.getPageSource().contains("Please enter first name")){
			System.out.println("Mandatory msg displayed'Please enter first name'");
			}else{
			System.out.println("Mandatory msg not displayed");
			}
	    	
}

public void Edit_User_LastName(String LN) throws InterruptedException {
	//Edit user
		Thread.sleep(3000);
	    
	    driver.findElement(By.id("mat-input-4")).clear();//LastName
	    
	    driver.findElement(By.id("mat-input-4")).sendKeys(LN);//LastName 
	    
	  //Submit
	    
	    driver.findElement(By.xpath("//*[@id=\"add-edit-user-dialog\"]/mat-dialog-content/div[2]/form/div[3]/div[1]/button/span[1]")).click(); //admin
	 
	    Thread.sleep(3000);
		
		if(driver.getPageSource().contains("Please enter last name")){
			System.out.println("Mandatory msg displayed'Please enter last name'");
			}else{
			System.out.println("Mandatory msg not displayed");
			}
	    	
}
public void Edit_User_emailId(String emailId) throws InterruptedException {
	//Edit user
		Thread.sleep(3000);
	    

	    driver.findElement(By.id("mat-input-5")).clear();//emailId
	    
	    Thread.sleep(3000);
	    
	    driver.findElement(By.id("mat-input-5")).sendKeys(emailId);//emailId
	    
	  //Submit
	    
	    driver.findElement(By.xpath("//*[@id=\"add-edit-user-dialog\"]/mat-dialog-content/div[2]/form/div[3]/div[1]/button/span[1]")).click(); //admin
	 
	    Thread.sleep(3000);
		
		if(driver.getPageSource().contains("User edited successfully.")){
			System.out.println("Mandatory msg displayed'User edited successfully.'");
			}else{
			System.out.println("Mandatory msg not displayed");
			}	
}
public void Edit_User_MobileNo(String MN) throws InterruptedException {
	//Edit user
		Thread.sleep(3000);
	    

	    driver.findElement(By.id("mat-input-6")).clear();//MobNo
	    
	    driver.findElement(By.id("mat-input-6")).sendKeys(MN);//MobNo
	    
	  //Submit
	    
	    driver.findElement(By.xpath("//*[@id=\"add-edit-user-dialog\"]/mat-dialog-content/div[2]/form/div[3]/div[1]/button/span[1]")).click(); //admin
	 
	    Thread.sleep(3000);
		
		if(driver.getPageSource().contains("Please enter valid mobile number")){
			System.out.println("Mandatory msg displayed'Please enter valid mobile number'");
			}else{
			System.out.println("Mandatory msg not displayed");
			}	

}

public void Edit_User_Role_To_standard() throws InterruptedException {
	//Edit user
	Thread.sleep(3000);
    
  
    //Change role
    
    Thread.sleep(3000);
    
    driver.findElement(By.xpath("//*[@id=\"mat-select-60\"]/div/div[2]")).click(); //select role in dropdown
  
    Thread.sleep(3000);
    
    //standard
    
    driver.findElement(By.xpath("//*[@id=\"mat-option-84\"]/span")).click();
    
    //Submit
    
    driver.findElement(By.xpath("//*[@id=\"add-edit-user-dialog\"]/mat-dialog-content/div[2]/form/div[3]/div[1]/button/span[1]")).click(); //admin
 
}

public void Edit_User_Role_To_admin() throws InterruptedException {
	//Edit user
	Thread.sleep(3000);
    

     //Change role
     
     Thread.sleep(3000);
     
     driver.findElement(By.xpath("//*[@id=\\\"mat-select-60\\\"]/div/div[2]")).click(); //select role in dropdown
   
     Thread.sleep(3000);
     
     //admin
     
     driver.findElement(By.xpath("//*[@id=\"mat-option-83\"]/span")).click(); 
     
     //Submit
     
	    driver.findElement(By.xpath("//*[@id=\"add-edit-user-dialog\"]/mat-dialog-content/div[2]/form/div[3]/div[1]/button/span[1]")).click(); //admin
  
}
public void Edit_User_Role_To_User() throws InterruptedException {
	//Edit user
	Thread.sleep(3000);
    

     //Change role
     
     Thread.sleep(3000);
     
     driver.findElement(By.xpath("//*[@id=\\\"mat-select-60\\\"]/div/div[2]")).click(); //select role in dropdown
   
     Thread.sleep(3000);
     
     //User
     
     driver.findElement(By.xpath("//*[@id=\"mat-option-85\"]/span")).click(); 
     
     //Submit
     
	    driver.findElement(By.xpath("//*[@id=\"add-edit-user-dialog\"]/mat-dialog-content/div[2]/form/div[3]/div[1]/button/span[1]")).click(); //admin
  
}
public void Select_User_Status_Active() throws InterruptedException {

	//Click on Dropdown
	
	Thread.sleep(3000);
    
    
    driver.findElement(By.xpath("//*[@id=\"mat-select-6\"]/div/div[2]")).click(); 
    
    //select active
    
    Thread.sleep(3000);
        
    driver.findElement(By.xpath("//*[@id=\"mat-option-10\"]/span")).click(); 
  
    
    //submit
    
    Thread.sleep(2000);

    driver.findElement(By.xpath("//*[@id=\"add-edit-user-dialog\"]/mat-dialog-content/div[2]/form/div[3]/div[1]/button/span[1]")).click(); 

}
public void Select_User_Status_Inactive() throws InterruptedException {

	//Click on Dropdown
	
	Thread.sleep(3000);
    
    
    driver.findElement(By.xpath("//*[@id=\"mat-select-6\"]/div/div[2]")).click(); 
    
    //select inactive
    
    Thread.sleep(3000);
    
    driver.findElement(By.xpath("//*[@id=\"mat-option-11\"]/span")).click(); 
    
    //submit
    
    Thread.sleep(2000);

    driver.findElement(By.xpath("//*[@id=\"add-edit-user-dialog\"]/mat-dialog-content/div[2]/form/div[3]/div[1]/button/span[1]")).click();    
}
public void Select_User_Status_Pending() throws InterruptedException {

	//Click on Dropdown
	
	Thread.sleep(3000);
    
    
    driver.findElement(By.xpath("//*[@id=\"mat-select-6\"]/div/div[2]")).click(); 
    
    //select Pending
    
    Thread.sleep(3000);
        
    driver.findElement(By.xpath("//*[@id=\"mat-option-09\"]/span")).click(); 
  
    
    //submit
    
    Thread.sleep(2000);

    driver.findElement(By.xpath("//*[@id=\"add-edit-user-dialog\"]/mat-dialog-content/div[2]/form/div[3]/div[1]/button/span[1]")).click(); 

}
public void Cancel() throws InterruptedException {
	
	Thread.sleep(3000);
    
    //click on cancel
    
    driver.findElement(By.xpath("//*[@id=\"add-edit-user-dialog\"]/mat-dialog-content/div[2]/form/div[4]/div[2]/button/span[1]")).click(); 	
}
public void Delete_User() throws InterruptedException {

     Thread.sleep(3000);
    
    //click on Delete
    
    driver.findElement(By.xpath("//*[@id=\"userlist-page\"]/div/table/tbody/tr[5]/td[5]/button[2]/span[1]/mat-icon")).click();
    
    //click on Confirm
    
    driver.findElement(By.xpath("//*[@id=\"dialogconfirm-page\"]/div/div[2]/button[1]/span[1]")).click();
    
    
}
public void Search_User_By_Name(String userName) throws InterruptedException {

    Thread.sleep(3000);
   
   //click on search tab
   
   driver.findElement(By.xpath("//*[@id=\"mat-input-2\"]")).sendKeys(userName); 	
}
public void Items_per_page_10() throws InterruptedException {
	//click on arrow
	   
	   Thread.sleep(2000);
	   
	   driver.findElement(By.xpath("//*[@id=\"mat-select-4\"]/div/div[2]")).click();
	
     //click on 10
	   
	   Thread.sleep(2000);
	   
	   driver.findElement(By.xpath("//*[@id=\"mat-option-8\"]/span")).click();
	 
	   
}
public void Items_per_page_50() throws InterruptedException {
	//click on arrow
	   
	   Thread.sleep(2000);
	   
	   driver.findElement(By.xpath("//*[@id=\\\"mat-select-4\\\"]/div/div[2]")).click();
	   
     //click on 50
	   
	   Thread.sleep(2000);
	   
	   driver.findElement(By.xpath("//*[@id=\"mat-option-9\"]/span")).click();	   
}
public void Next_Page_click() throws InterruptedException {
	//click on arrow
	   
	   Thread.sleep(2000);
	   
	   driver.findElement(By.xpath("//*[@id=\"userlist-page\"]/div/mat-paginator/div/div/div[2]/button[3]/span[1]")).click();
	   	   
}
}


