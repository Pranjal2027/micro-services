package com.Xuriti.admin_panel_main;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Manage_Companies_Edit {
WebDriver driver;
	
	
	public Manage_Companies_Edit(WebDriver driver) throws InterruptedException {
		this.driver = driver;
			
}
public void Edit_company() throws InterruptedException {
	
	//click on manage company
	
	Thread.sleep(5000);
	driver.findElement(By.xpath("/html/body/app-root/app-companylist/app-layout/mat-sidenav-container/mat-sidenav/div/app-sidebar/div/div/div[3]/mat-nav-list/mat-list-item[3]/span/mat-icon")).click();
	
	//Click on Edit_Company
	 
	Thread.sleep(3000);
	
	driver.findElement(By.xpath("//*[@id=\"companylist-page\"]/div/table/tbody/tr[6]/td[6]/button[1]/span[1]/mat-icon")).click(); 	
	
}
public void Search_by_company_name(String Company_name) throws InterruptedException {

	//Enter Company_name
    
	Thread.sleep(2000);
	
    driver.findElement(By.xpath("//*[@id=\"mat-input-2\"]")).sendKeys(Company_name);
    
}
public void Search_by_GST_NO(String GST_NO) throws InterruptedException {

	//Enter Company_name
    
	Thread.sleep(2000);
	
    driver.findElement(By.xpath("//*[@id=\"mat-input-3\"]")).sendKeys(GST_NO);
    
}

public void Search_by_date_range_based_on_registration(String SD, String ED) throws InterruptedException {

	//click date range
    
	Thread.sleep(2000);
	
    driver.findElement(By.xpath("//*[@id=\"mat-date-range-input-0\"]")).click();
    
    //Start date
    
    Thread.sleep(2000);
    
    driver.findElement(By.xpath("//*[@id=\"mat-date-range-input-0\"]")).sendKeys(SD);  
    
    //End date
    
    Thread.sleep(2000);
    
    driver.findElement(By.xpath("//*[@id=\"companylist-page\"]/div/div/mat-form-field[4]/div/div[1]/div[3]/mat-date-range-input/div/div[2]/input")).sendKeys(ED);  
}
public void Search_by_Approve_company() throws InterruptedException {
	
	// Select_Company_Status
	 
	Thread.sleep(3000);
	
	driver.findElement(By.xpath("//*[@id=\"mat-select-0\"]/div")).click(); 	
	
	//APPROVED
	
	driver.findElement(By.xpath("//*[@id=\"mat-option-3\"]/span")).click(); 	
}
public void Search_by_Hold_company() throws InterruptedException {
 
	// Select_Company_Status
	 
	Thread.sleep(3000);
		
	driver.findElement(By.xpath("//*[@id=\"mat-select-0\"]/div")).click(); 	
		
	//Hold_company
		
	driver.findElement(By.xpath("//*[@id=\"mat-option-2\"]/span")).click();	
}
public void Search_by_INACTIVE_company() throws InterruptedException {
	 
	// Select_Company_Status
	 
	Thread.sleep(3000);
		
	driver.findElement(By.xpath("//*[@id=\"mat-option-1\"]/span")).click(); 	
		
	//Inactive_company
		
	driver.findElement(By.xpath("//*[@id=\"mat-option-42\"]/span")).click(); 	
}
public void Edit_Company_Status_Inactive() throws InterruptedException {

	//click on company Status
    
	Thread.sleep(2000);
	
    driver.findElement(By.xpath("//*[@id=\"mat-select-4\"]")).click();
    
    //INACTIVE
    
    driver.findElement(By.xpath("//*[@id=\"mat-option-7\"]/span")).click();   
}
public void Edit_Company_Status_HOLD() throws InterruptedException {

	//click on company Status
    
	Thread.sleep(2000);
	
    driver.findElement(By.xpath("//*[@id=\"mat-select-4\"]")).click();
    
    //HOLD
    
    driver.findElement(By.xpath("//*[@id=\"mat-option-8\"]/span")).click();    
}
public void Edit_Company_Status_Approved() throws InterruptedException {

	//click on company Status[click on approved]
    
	Thread.sleep(2000);
	
    driver.findElement(By.xpath("//*[@id=\"mat-select-4\"]")).click();
    
    //Approved
    
    driver.findElement(By.xpath("//*[@id=\"mat-option-9\"]/span")).click();   
}
public void Gst_NO(String Gst_NO) throws InterruptedException {
	
	//Click on Gst_NO
	 	
	Thread.sleep(3000);
    
    driver.findElement(By.id("mat-input-4")).clear();//Gst_NO
    
    driver.findElement(By.id("mat-input-4")).sendKeys(Gst_NO);
    
  //Submit
    
   // driver.findElement(By.xpath("//*[@id=\"companydetails-page\"]/div/mat-card/mat-card-content/div/form/div[2]/button")).click(); //admin
 
    Thread.sleep(3000);
	
	if(driver.getPageSource().contains("Please enter correct GST number")){
		System.out.println("Mandatory msg displayed'Please enter correct GST numbe'");
		}else{
		System.out.println("Mandatory msg not displayed");
		}
}
public void Company_Name(String Company_Name) throws InterruptedException {
	
	//Click on Company_Name
	 	
	Thread.sleep(3000);
    
    driver.findElement(By.id("mat-input-5")).clear();//Company_Name
    
    driver.findElement(By.id("mat-input-5")).sendKeys(Company_Name);
    
  //Submit
    
   // driver.findElement(By.xpath("//*[@id=\"companydetails-page\"]/div/mat-card/mat-card-content/div/form/div[2]/button")).click(); //admin
 
    Thread.sleep(3000);
	
	if(driver.getPageSource().contains("Please enter company name")){
		System.out.println("Mandatory msg displayed'Please enter company name'");
		}else{
		System.out.println("Mandatory msg not displayed");
		}
}
public void Company_mobile_number(String MN) throws InterruptedException {
	
	//Click on Admin_Name
	 	
	Thread.sleep(3000);
    
    driver.findElement(By.id("mat-input-6")).clear();//MN
    
    driver.findElement(By.id("mat-input-6")).sendKeys(MN);
    
  //Submit
    
  //  driver.findElement(By.xpath("//*[@id=\"companydetails-page\"]/div/mat-card/mat-card-content/div/form/div[2]/button")).click(); //admin
 
    Thread.sleep(3000);
	
	if(driver.getPageSource().contains("Please enter valid mobile number")){
		System.out.println("Mandatory msg displayed'Please enter valid mobile number'");
		}else{
		System.out.println("Mandatory msg not displayed");
		}
}
public void Company_Email_add(String Cemail) throws InterruptedException {
	
	//Click on Admin_Name
	 
	
	Thread.sleep(3000);
    
    driver.findElement(By.id("mat-input-7")).clear();//Cemail
    
    driver.findElement(By.id("mat-input-7")).sendKeys(Cemail);
    
  //Submit
    
  //  driver.findElement(By.xpath("//*[@id=\"companydetails-page\"]/div/mat-card/mat-card-content/div/form/div[2]/button")).click(); //admin
 
}
public void Admin_Name(String Admin_Name) throws InterruptedException {
	
	//Click on Admin_Name
	 
	
	Thread.sleep(3000);
    
    driver.findElement(By.id("mat-input-8")).clear();//AdminName
    
    driver.findElement(By.id("mat-input-8")).sendKeys(Admin_Name);
    
  //Submit
    
  //  driver.findElement(By.xpath("//*[@id=\"companydetails-page\"]/div/mat-card/mat-card-content/div/form/div[2]/button")).click(); //admin
 
    Thread.sleep(3000);
	
	if(driver.getPageSource().contains("Please enter admin name.")){
		System.out.println("Mandatory msg displayed'Please enter admin name.'");
		}else{
		System.out.println("Mandatory msg not displayed");
		}
}
public void Admin_Mobile_Num(String Admin_MN) throws InterruptedException {
	
	//Click on Admin_Name
	 
	
	Thread.sleep(3000);
    
    driver.findElement(By.id("mat-input-9")).clear();//Admin_MN
    
    driver.findElement(By.id("mat-input-9")).sendKeys(Admin_MN);
    
  //Submit
    
 //   driver.findElement(By.xpath("//*[@id=\"companydetails-page\"]/div/mat-card/mat-card-content/div/form/div[2]/button")).click(); //admin
 
    Thread.sleep(3000);
	
	if(driver.getPageSource().contains("Please enter valid mobile number")){
		System.out.println("Mandatory msg displayed'Please enter valid mobile number'");
		}else{
		System.out.println("Mandatory msg not displayed");
		}
}
public void Company_PAN(String PAN) throws InterruptedException {
	
	//Click on Admin_Name
	 
	
	Thread.sleep(3000);
    
    driver.findElement(By.id("mat-input-10")).clear();//PAN
    
    driver.findElement(By.id("mat-input-10")).sendKeys(PAN);
    
  //Submit
    
   // driver.findElement(By.xpath("//*[@id=\"companydetails-page\"]/div/mat-card/mat-card-content/div/form/div[2]/button")).click(); //admin
}

public void CIN(String CIN) throws InterruptedException {
	
	//Click on Admin_Name
	 
	
	Thread.sleep(3000);
    
    driver.findElement(By.id("mat-input-11")).clear();//CIN
    
    driver.findElement(By.id("mat-input-11")).sendKeys(CIN);
    
  //Submit
    
  //  driver.findElement(By.xpath("//*[@id=\"companydetails-page\"]/div/mat-card/mat-card-content/div/form/div[2]/button")).click(); //admin
 
    Thread.sleep(3000);
	
	if(driver.getPageSource().contains("Please enter correct CIN number")){
		System.out.println("Mandatory msg displayed'Please enter correct CIN number'");
		}else{
		System.out.println("Mandatory msg not displayed");
		}
}
public void Annual_Turnover(String Turnover) throws InterruptedException {
	
	//Click on Admin_Name
	
	Thread.sleep(3000);
    
	 driver.findElement(By.id("mat-input-12")).clear();//CIN
    
    driver.findElement(By.id("mat-input-12")).sendKeys(Turnover);
    
  //Submit
    
   // driver.findElement(By.xpath("//*[@id=\"companydetails-page\"]/div/mat-card/mat-card-content/div/form/div[2]/button")).click(); //admin
}
public void District(String District) throws InterruptedException {
	
	//Click on District
	 
	
	Thread.sleep(3000);
    
    driver.findElement(By.id("mat-input-13")).clear();//District
    
    driver.findElement(By.id("mat-input-13")).sendKeys(District);
    
  //Submit
    
   // driver.findElement(By.xpath("//*[@id=\"companydetails-page\"]/div/mat-card/mat-card-content/div/form/div[2]/button")).click(); //admin

}
public void State(String State) throws InterruptedException {
	
	//Click on State
	 	
	Thread.sleep(3000);
    
    driver.findElement(By.id("mat-input-14")).clear();//State
    
    driver.findElement(By.id("mat-input-14")).sendKeys(State);
    
  //Submit
    
    driver.findElement(By.xpath("//*[@id=\"companydetails-page\"]/div/mat-card/mat-card-content/div/form/div[2]/button")).click(); //admin
}

public void Pin_code(String Pin_code) throws InterruptedException {
	
	//Click on Admin_Name
	 
	
	Thread.sleep(3000);
    
    driver.findElement(By.id("mat-input-15")).clear();//Pin_code
    
    driver.findElement(By.id("mat-input-15")).sendKeys(Pin_code);
    
  //Submit
    
   // driver.findElement(By.xpath("//*[@id=\"companydetails-page\"]/div/mat-card/mat-card-content/div/form/div[2]/button")).click(); //admin

    Thread.sleep(3000);
	
	if(driver.getPageSource().contains("Please enter correct PinCode")){
		System.out.println("Mandatory msg displayed'Please enter correct PinCode'");
		}else{
		System.out.println("Mandatory msg not displayed");
		}
}
public void Admin_Email_Add(String Admin_Email) throws InterruptedException {
	
	//Click on Admin_Name
		
	Thread.sleep(3000);
    
    driver.findElement(By.id("mat-input-16")).clear();//Admin_Email
    
    driver.findElement(By.id("mat-input-16")).sendKeys(Admin_Email);
    
  //Submit
    
  //  driver.findElement(By.xpath("//*[@id=\"companydetails-page\"]/div/mat-card/mat-card-content/div/form/div[2]/button")).click(); //admin
 
    Thread.sleep(3000);
	
	if(driver.getPageSource().contains("Please enter valid email address")){
		System.out.println("Mandatory msg displayed'Please enter valid email address'");
		}else{
		System.out.println("Mandatory msg not displayed");
		}
}
public void Type_Of_Business(String Type_B) throws InterruptedException {
	
	//Click on Admin_Name
	 	
	Thread.sleep(3000);
    
    driver.findElement(By.id("mat-input-17")).clear();//Type_B
    
    driver.findElement(By.id("mat-input-17")).sendKeys(Type_B);
    
  //Submit
    
  //  driver.findElement(By.xpath("//*[@id=\"companydetails-page\"]/div/mat-card/mat-card-content/div/form/div[2]/button")).click(); //admin
 
    Thread.sleep(3000);
	
	if(driver.getPageSource().contains("Please enter admin name.")){
		System.out.println("Mandatory msg displayed'Please enter admin name.'");
		}else{
		System.out.println("Mandatory msg not displayed");
		}
}
public void TAN(String TAN) throws InterruptedException {
	
	//Click on Admin_Name
	 
	
	Thread.sleep(3000);
    
    driver.findElement(By.id("mat-input-18")).clear();//TAN
    
    driver.findElement(By.id("mat-input-18")).sendKeys(TAN);
    
  //Submit
    
  //  driver.findElement(By.xpath("//*[@id=\"companydetails-page\"]/div/mat-card/mat-card-content/div/form/div[2]/button")).click(); //admin
 
    Thread.sleep(3000);
	
	if(driver.getPageSource().contains("Please enter correct TAN number")){
		System.out.println("Mandatory msg displayed'Please enter correct TAN number'");
		}else{
		System.out.println("Mandatory msg not displayed");
		}
}
public void Credit_Limit(String Credit_Limit) throws InterruptedException {
	
	//Click on Admin_Name
	
	Thread.sleep(3000);
    
    driver.findElement(By.id("mat-input-19")).clear();//Credit_Limit
    
    driver.findElement(By.id("mat-input-19")).sendKeys(Credit_Limit);
    
  //Submit
    
  //  driver.findElement(By.xpath("//*[@id=\"companydetails-page\"]/div/mat-card/mat-card-content/div/form/div[2]/button")).click(); //admin
 
    Thread.sleep(3000);
	
	if(driver.getPageSource().contains("Please enter valid Amount")){
		System.out.println("Mandatory msg displayed'Please enter valid Amount'");
		}else{
		System.out.println("Mandatory msg not displayed");
		}
}
public void Intrest(String Intrest) throws InterruptedException {
	
	//Click on Admin_Name
	 
	
	Thread.sleep(3000);
    
    driver.findElement(By.id("mat-input-20")).clear();//Intrest
    
    driver.findElement(By.id("mat-input-20")).sendKeys(Intrest);
    
  //Submit
    
   // driver.findElement(By.xpath("//*[@id=\"companydetails-page\"]/div/mat-card/mat-card-content/div/form/div[2]/button")).click(); //admin
 
    Thread.sleep(3000);
	
	if(driver.getPageSource().contains("Please enter valid interest %")){
		System.out.println("Mandatory msg displayed'Please enter valid interest %'");
		}else{
		System.out.println("Mandatory msg not displayed");
		}
}
public void Credit_Plan() throws InterruptedException {
	
	//Click on Edit_Users
	 
	Thread.sleep(3000);
	
	driver.findElement(By.xpath("//*[@id=\"companylist-page\"]/div/table/tbody/tr[8]/td[6]/button[2]/span[1]/mat-icon")).click(); 	
}
public void Click_on_Credit_plan() throws InterruptedException {
	
	//Click on credit_plan
	 
	Thread.sleep(3000);
	
	driver.findElement(By.xpath("//*[@id=\"companylist-page\"]/div/table/tbody/tr[8]/td[6]/button[2]/span[1]/mat-icon")).click(); 	
	
}
public void Add_Plan() throws InterruptedException {
	 
	Thread.sleep(3000);
	
	driver.findElement(By.xpath("//*[@id=\"creditplanslist-page\"]/div/div[1]/button[2]/span[1]")).click(); 	
}
public void Credit_plan_name(String PlanName) throws InterruptedException {
	
	//plan_name
	 
	Thread.sleep(3000);
	
	driver.findElement(By.xpath("//*[@id=\"mat-input-4\"]")).sendKeys(PlanName); 	
Thread.sleep(3000);
	
	if(driver.getPageSource().contains("Please enter plan name")){
		System.out.println("Mandatory msg displayed'Please enter plan name'");
		}else{
		System.out.println("Mandatory msg not displayed");
		}
}
public void Credit_Free_Period(String Credit_Period) throws InterruptedException {
	
	//Credit_Free_Period
	 
	Thread.sleep(3000);
	
	driver.findElement(By.xpath("//*[@id=\"mat-input-5\"]")).sendKeys(Credit_Period); 	

	Thread.sleep(3000);
	
	if(driver.getPageSource().contains("Please enter credit free period")){
		System.out.println("Mandatory msg displayed'Please enter credit free period'");
		}else{
		System.out.println("Mandatory msg not displayed");
		}
}
public void Number_of_Payment_Interval_1() throws InterruptedException {
	
	Thread.sleep(3000);
    
	driver.findElement(By.xpath("//*[@id=\"mat-select-value-7\"]")).click(); 	

	Thread.sleep(3000);
	
    driver.findElement(By.xpath("//*[@id=\"mat-option-10\"]/span")).click();
    
 
    Thread.sleep(3000);
	
	if(driver.getPageSource().contains("Please enter payment interval")){
		System.out.println("Mandatory msg displayed'Please enter payment interval'");
		}else{
		System.out.println("Mandatory msg not displayed");
		}
}
public void Number_of_Payment_Interval_2() throws InterruptedException {
	
	Thread.sleep(3000);
    
	driver.findElement(By.xpath("//*[@id=\"mat-select-value-7\"]")).click(); 	

	Thread.sleep(3000);
	
    driver.findElement(By.xpath("//*[@id=\"mat-option-11\"]/span")).click();
    
 
    Thread.sleep(3000);
	
	if(driver.getPageSource().contains("Please enter payment interval")){
		System.out.println("Mandatory msg displayed'Please enter payment interval'");
		}else{
		System.out.println("Mandatory msg not displayed");
		}
}
public void Number_of_Payment_Interval_3() throws InterruptedException {
	
	Thread.sleep(3000);
    
	driver.findElement(By.xpath("//*[@id=\"mat-select-value-7\"]")).click(); 	

	Thread.sleep(3000);
	
    driver.findElement(By.xpath("//*[@id=\"mat-option-12\"]/span")).click();
    
 
    Thread.sleep(3000);
	
	if(driver.getPageSource().contains("Please enter payment interval")){
		System.out.println("Mandatory msg displayed'Please enter payment interval'");
		}else{
		System.out.println("Mandatory msg not displayed");
		}
}
public void Number_of_Payment_Interval_4() throws InterruptedException {
	
	Thread.sleep(3000);
    
	driver.findElement(By.xpath("//*[@id=\"mat-select-value-7\"]")).click(); 	

	Thread.sleep(3000);
	
    driver.findElement(By.xpath("//*[@id=\"mat-option-13\"]/span")).click();
    
 
    Thread.sleep(3000);
	
	if(driver.getPageSource().contains("Please enter payment interval")){
		System.out.println("Mandatory msg displayed'Please enter payment interval'");
		}else{
		System.out.println("Mandatory msg not displayed");
		}
}
public void Number_of_Payment_Interval_5() throws InterruptedException {
	
	Thread.sleep(3000);
    
	driver.findElement(By.xpath("//*[@id=\"mat-select-value-7\"]")).click(); 	

	Thread.sleep(3000);
	
    driver.findElement(By.xpath("//*[@id=\"mat-option-14\"]/span")).click();
    
 
    Thread.sleep(3000);
	
	if(driver.getPageSource().contains("Please enter payment interval")){
		System.out.println("Mandatory msg displayed'Please enter payment interval'");
		}else{
		System.out.println("Mandatory msg not displayed");
		}
}
public void Number_of_Payment_Interval_6() throws InterruptedException {
	
	Thread.sleep(3000);
    
	driver.findElement(By.xpath("//*[@id=\"mat-select-value-7\"]")).click(); 	

	Thread.sleep(3000);
	
    driver.findElement(By.xpath("//*[@id=\"mat-option-15\"]/span")).click();
    
 
    Thread.sleep(3000);
	
	if(driver.getPageSource().contains("Please enter payment interval")){
		System.out.println("Mandatory msg displayed'Please enter payment interval'");
		}else{
		System.out.println("Mandatory msg not displayed");
		}
}
public void Number_of_Payment_Interval_7() throws InterruptedException {
	
	Thread.sleep(3000);
    
	driver.findElement(By.xpath("//*[@id=\"mat-select-value-7\"]")).click(); 	

	Thread.sleep(3000);
	
    driver.findElement(By.xpath("//*[@id=\"mat-option-16\"]/span")).click();
    
 
    Thread.sleep(3000);
	
	if(driver.getPageSource().contains("Please enter payment interval")){
		System.out.println("Mandatory msg displayed'Please enter payment interval'");
		}else{
		System.out.println("Mandatory msg not displayed");
		}
}
public void Discount_Interval_1(String Discount_Interval,String Discount) throws InterruptedException {
	
	//Click on Discount_Interval
	
	Thread.sleep(2000);
	
	//from part not enabled(id-2)
	
	//to part 
	
    driver.findElement(By.id("mat-input-7")).sendKeys(Discount_Interval);

    //discount %
    
    Thread.sleep(2000);
    
    driver.findElement(By.id("mat-input-8")).sendKeys(Discount);
    
    //if no of payment intevals are 2 again from & to will repeat again with ('from' id-9, 'to' id-10)
    
}
public void Save_option_of_credit_plan() throws InterruptedException {

Thread.sleep(2000);

driver.findElement(By.xpath("//*[@id=\"creditplans-page\"]/form/div[2]/button")).click();
}
public void Discount_Interval_2(String Discount_Interval,String Discount) throws InterruptedException {
	
	//Click on Discount_Interval
	
	Thread.sleep(2000);
	
	//from part not enabled(id-6)
	
	//discount interval "from" 
	
//	Thread.sleep(2000);
	
  //  driver.findElement(By.id("mat-input-9")).sendKeys(Discount_Interval);
	
	
	//discount interval "to"
    
	Thread.sleep(2000);
	
    driver.findElement(By.id("mat-input-10")).sendKeys(Discount_Interval);

    //discount %
    
	Thread.sleep(2000);
    
    driver.findElement(By.id("mat-input-11")).sendKeys(Discount);
    
//    //save
//    
//    Thread.sleep(2000);
//    
//    driver.findElement(By.xpath("//*[@id=\"creditplans-page\"]/form/div[2]/button")).click(); 
//    
    //if no of payment intevals are 2 again from & to will repeat again with ('from' id-9, 'to' id-10)
    
}
public void Discount_Interval_3(String Discount_Interval,String Discount) throws InterruptedException {
	
	//Click on Discount_Interval
	
	Thread.sleep(2000);
	
	//from part not enabled(id-6)
	
	//discount interval "from" 
	
	//Thread.sleep(2000);
	
   // driver.findElement(By.id("mat-input-12")).sendKeys(Discount_Interval);
	
	
	//discount interval "to"
    
	Thread.sleep(2000);
	
    driver.findElement(By.id("mat-input-13")).sendKeys(Discount_Interval);

    //discount %
    
	Thread.sleep(2000);
    
    driver.findElement(By.id("mat-input-14")).sendKeys(Discount);
    
//    //save
//    
//    Thread.sleep(2000);
//    
//    driver.findElement(By.xpath("//*[@id=\"creditplans-page\"]/form/div[2]/button")).click(); 
    
    //if no of payment intevals are 2 again from & to will repeat again with ('from' id-9, 'to' id-10)
    
}
public void Discount_Interval_4(String Discount_Interval,String Discount) throws InterruptedException {
	
	//Click on Discount_Interval
	
	//Thread.sleep(2000);
	
	//from part not enabled(id-6)
	
	//discount interval "from" 
	
	//Thread.sleep(2000);
	
  //  driver.findElement(By.id("mat-input-15")).sendKeys(Discount_Interval);
	
	
	//discount interval "to"
    
	Thread.sleep(2000);
	
    driver.findElement(By.id("mat-input-16")).sendKeys(Discount_Interval);

    //discount %
    
	Thread.sleep(2000);
    
    driver.findElement(By.id("mat-input-17")).sendKeys(Discount);
    
    //save
    
   // Thread.sleep(2000);
    
   // driver.findElement(By.xpath("//*[@id=\"creditplans-page\"]/form/div[2]/button")).click(); 
    
    //if no of payment intevals are 2 again from & to will repeat again with ('from' id-9, 'to' id-10)
    
}
public void Discount_Interval_5(String Discount_Interval,String Discount) throws InterruptedException {
	
	//Click on Discount_Interval
	
//	Thread.sleep(2000);
	
	//from part not enabled(id-6)
	
	//discount interval "from" 
	
//	Thread.sleep(2000);
	
 //   driver.findElement(By.id("mat-input-18")).sendKeys(Discount_Interval);
	
	
	//discount interval "to"
    
	Thread.sleep(2000);
	
    driver.findElement(By.id("mat-input-19")).sendKeys(Discount_Interval);

    //discount %
    
	Thread.sleep(2000);
    
    driver.findElement(By.id("mat-input-20")).sendKeys(Discount);
    
    //save
    
  //  Thread.sleep(2000);
    
    //driver.findElement(By.xpath("//*[@id=\"creditplans-page\"]/form/div[2]/button")).click(); 
    
    //if no of payment intevals are 2 again from & to will repeat again with ('from' id-9, 'to' id-10)
    
}
public void Discount_Interval_6(String Discount_Interval,String Discount) throws InterruptedException {
	
	//Click on Discount_Interval
	
	//Thread.sleep(2000);
	
	//from part not enabled(id-6)
	
	//discount interval "from" 
	
	//Thread.sleep(2000);
	
  //  driver.findElement(By.id("mat-input-21")).sendKeys(Discount_Interval);
	
	
	//discount interval "to"
    
	Thread.sleep(2000);
	
    driver.findElement(By.id("mat-input-22")).sendKeys(Discount_Interval);

    //discount %
    
	Thread.sleep(2000);
    
    driver.findElement(By.id("mat-input-23")).sendKeys(Discount);
    
    //save
    
  //  Thread.sleep(2000);
    
    //driver.findElement(By.xpath("//*[@id=\"creditplans-page\"]/form/div[2]/button")).click(); 
    
    //if no of payment intevals are 2 again from & to will repeat again with ('from' id-9, 'to' id-10)
    
}
public void Discount_Interval_7(String Discount_Interval,String Discount) throws InterruptedException {
	
	//Click on Discount_Interval
	
	//Thread.sleep(2000);
	
	//from part not enabled(id-6)
	
	//discount interval "from" 
	
	//Thread.sleep(2000);
	
  //  driver.findElement(By.id("mat-input-24")).sendKeys(Discount_Interval);
	
	
	//discount interval "to"
    
	Thread.sleep(2000);
	
    driver.findElement(By.id("mat-input-25")).sendKeys(Discount_Interval);

    //discount %
    
	Thread.sleep(2000);
    
    driver.findElement(By.id("mat-input-26")).sendKeys(Discount);
    
    //save
    
  //  Thread.sleep(2000);
    
   // driver.findElement(By.xpath("//*[@id=\"creditplans-page\"]/form/div[2]/button")).click(); 
    
    //if no of payment intevals are 2 again from & to will repeat again with ('from' id-9, 'to' id-10)
    
}

public void Items_per_page_20() throws InterruptedException {
	//click on arrow
	   
	   Thread.sleep(2000);
	   
	   driver.findElement(By.xpath("//*[@id=\"mat-select-2\"]/div/div[2]")).click();
	
     //click on 10
	   
	   Thread.sleep(2000);
	   
	   driver.findElement(By.xpath("//*[@id=\"mat-option-5\"]/span")).click();
	 
	   
}
public void Items_per_page_50() throws InterruptedException {
	//click on arrow
	   
	   Thread.sleep(2000);
	   
	   driver.findElement(By.xpath("//*[@id=\"mat-select-2\"]/div/div[2]")).click();
	   
     //click on 50
	   
	   Thread.sleep(2000);
	   
	   driver.findElement(By.xpath("//*[@id=\"mat-option-6\"]/span")).click();	   
}
public void Next_Page_click() throws InterruptedException {
	//click on arrow
	   
	   Thread.sleep(2000);
	   
	   driver.findElement(By.xpath("//*[@id=\"companylist-page\"]/div/mat-paginator/div/div/div[2]/button[3]/span[1]")).click();
	   	   
}
}

