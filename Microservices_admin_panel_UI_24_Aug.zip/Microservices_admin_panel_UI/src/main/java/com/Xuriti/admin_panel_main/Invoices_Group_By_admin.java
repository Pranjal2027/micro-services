package com.Xuriti.admin_panel_main;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebElement;
//import org.openqa.selenium.interactions.Actions;
//import org.openqa.selenium.support.ui.Select;


public class Invoices_Group_By_admin {
WebDriver driver;
		
	public Invoices_Group_By_admin  (WebDriver driver) throws InterruptedException {
		this.driver = driver;
	
		//Click on Invoices
		 
		Thread.sleep(3000);
				
     driver.findElement(By.xpath("/html/body/app-root/app-dashboard/app-layout/mat-sidenav-container/mat-sidenav/div/app-sidebar/div/div/div[3]/mat-nav-list/mat-list-item[2]/span/mat-icon")).click(); 
	
   //driver.findElement(By.xpath("/html/body/app-root/app-buyerinvoices/app-layout/mat-sidenav-container/mat-sidenav/div/app-sidebar/div/div/div[3]/mat-nav-list/mat-list-item[1]/span/mat-icon")).click();
	}

public void Invoice_due_date_2days() throws InterruptedException {
	
	// click on due date
	
	//click on dropdown arrow
	
	driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	
	//driver.findElement(By.xpath("//*[@id=\"mat-select-4\"]")).click();
	//driver.findElement(By.xpath("//*[@id=\"mat-select-16\"]/div/div[2]/div")).click();
	
	driver.findElement(By.xpath("//*[@id=\"mat-select-2\"]/div/div[2]/div")).click();
	
	

	      // click on 2 days
	
	Thread.sleep(5000);
				
		driver.findElement(By.xpath("//*[@id=\"mat-option-4\"]/span")).click();
		
		
	}
public void Invoice_due_date_5days() throws InterruptedException {
	
	
	// click on due date
	
		//click on dropdown arrow
		
		//driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		
		//driver.findElement(By.xpath("//*[@id=\"mat-select-4\"]")).click();
		
		driver.findElement(By.xpath("//*[@id=\"mat-select-2\"]/div/div[2]/div")).click();


		      // click on 5 days
		
		Thread.sleep(3000);
					
			driver.findElement(By.xpath("//*[@id=\"mat-option-5\"]/span")).click();
		
	}
public void Invoice_due_date_7days() throws InterruptedException {
	
	
	// click on due date
	
		//click on dropdown arrow
		
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		
		driver.findElement(By.xpath("//*[@id=\"mat-select-2\"]/div/div[2]")).click();

		      // click on 7 days
		
		Thread.sleep(3000);
					
			driver.findElement(By.xpath("//*[@id=\"mat-option-6\"]/span")).click();
}
public void Invoice_due_date_10days() throws InterruptedException {
	
	
	// click on due date
	
		//click on dropdown arrow
		
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		
		driver.findElement(By.xpath("//*[@id=\"mat-select-2\"]/div/div[2]")).click();

		      // click on 10 days
		
		Thread.sleep(3000);
					
		driver.findElement(By.xpath("//*[@id=\"mat-option-7\"]/span")).click();
}
public void Search_by_invoice_number(String InvoiceN) throws InterruptedException {
	
	//Thread.sleep(5000);
	
	//driver.findElement(By.xpath("//*[@id=\"mat-input-2\"]")).sendKeys(InvoiceN);
	
	driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

	//WebDriverWait wait = new WebDriverWait(driver, 10);
	 
	// WebElement dropdown = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id=\\\"mat-input-2\\\"]")));
	
	// ((JavascriptExecutor)driver).executeScript("arguments[0].click()",dropdown);
	
//	driver.findElement(By.xpath("//*[@id=\"mat-input-4\"]")).sendKeys(InvoiceN);
	driver.findElement(By.xpath("//*[@id=\"mat-input-2\"]")).sendKeys(InvoiceN);

}
public void Invoice_Date(String InvoiceDate) throws InterruptedException {
	
	Thread.sleep(3000);

	
	driver.findElement(By.xpath("//*[@id=\"mat-input-3\"]")).sendKeys(InvoiceDate);

}

public void Invoice_Status_in_Pending() throws InterruptedException {
	
	//Invoice status in dropdown arrow
	
	Thread.sleep(3000);
	
	driver.findElement(By.xpath("//*[@id=\"mat-select-4\"]/div/div[2]")).click();
	//*[@id="mat-select-value-3"]/span
	
	//Pending
	
	Thread.sleep(3000);
	
	driver.findElement(By.xpath("//*[@id=\"mat-option-9\"]/span")).click();
}
public void Invoice_Status_in_Confirmed() throws InterruptedException {
	
	//Invoice status in dropdown arrow
	
	Thread.sleep(3000);
	
	driver.findElement(By.xpath("//*[@id=\"mat-select-4\"]/div/div[2]/div")).click();
		
	//Confirmed
		
		Thread.sleep(3000);
	
	driver.findElement(By.xpath("//*[@id=\"mat-option-10\"]/span")).click();
	
}
public void Invoice_Status_in_Rejected() throws InterruptedException {
	
	//Invoice status in dropdown arrow
	
	Thread.sleep(3000);
	
	driver.findElement(By.xpath("//*[@id=\"mat-select-4\"]/div/div[2]")).click();
	
	//Rejected
	
	Thread.sleep(3000);
	
	driver.findElement(By.xpath("//*[@id=\"mat-option-11\"]/span")).click();
}
public void Invoice_Status_in_Incomplete() throws InterruptedException {
	
	//Invoice status in dropdown arrow
	
	Thread.sleep(3000);
	
	driver.findElement(By.xpath("//*[@id=\"mat-select-4\"]/div/div[2]")).click();
	
	//Incomplete
	
	Thread.sleep(3000);
	
	driver.findElement(By.xpath("//*[@id=\"mat-option-12\"]/span")).click();
}
public void Invoice_Status_in_Buyer_Absent() throws InterruptedException {
	
	//Invoice status in dropdown arrow
	
	Thread.sleep(3000);
	
	driver.findElement(By.xpath("//*[@id=\"mat-select-4\"]/div/div[2]/div")).click();
	
	//Buyer Absent
	
	
	Thread.sleep(3000);
	
	driver.findElement(By.xpath("//*[@id=\"mat-option-14\"]/span")).click();
	
	
	//*[@id="mat-option-17"]/span
}
public void Invoice_Status_in_Seller_Absent() throws InterruptedException {
	
	//Invoice status in dropdown arrow
	
	Thread.sleep(3000);
	
	driver.findElement(By.xpath("//*[@id=\"mat-select-4\"]/div/div[2]/div")).click();
	
	//Seller Absent
	
//	Select se = new Select(driver.findElement(By.xpath("//*[@id=\\\"mat-select-6\\\"]/div")));
	
	//se.selectByValue("Seller Absent");

	
	driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	
	driver.findElement(By.xpath("//*[@id=\"mat-option-15\"]/span")).click();
	
}
public void Invoice_Status_Partpay() throws InterruptedException {
	
	//Invoice status in dropdown arrow
	
	Thread.sleep(3000);
	
	driver.findElement(By.xpath("//*[@id=\"mat-select-4\"]/div/div[2]/div")).click();
	
	//Partpay
	
	Thread.sleep(3000);
	
	driver.findElement(By.xpath("//*[@id=\"mat-option-16\"]/span")).click();
	//*[@id="mat-option-19"]/span
}
public void Invoice_Status_Duplicate() throws InterruptedException {
	
	//Invoice status in dropdown arrow
	
	Thread.sleep(3000);
	
	driver.findElement(By.xpath("//*[@id=\"mat-select-4\"]/div/div[2]/div")).click();
	
	//Duplicate
	
	Thread.sleep(3000);
	
	driver.findElement(By.xpath("//*[@id=\"mat-option-17\"]/span")).click();
	//*[@id="mat-option-20"]/span
}
public void Invoice_Status_in_Paid() throws InterruptedException {
	
	//Invoice status in dropdown arrow
	
	Thread.sleep(3000);
	
	driver.findElement(By.xpath("//*[@id=\"mat-select-4\"]/div/div[2]")).click();
	
	//Paid
	
	Thread.sleep(5000);
	
	driver.findElement(By.xpath("//*[@id=\"mat-option-18\"]/span")).click();
	//*[@id="mat-option-21"]/span
}

public void Select_User_Type_Buyer(String Buyer_Name) throws InterruptedException {
	
	Thread.sleep(3000);
	
	driver.findElement(By.xpath("//*[@id=\"mat-select-value-9\"]/span/span")).click();
	
	//Buyer
	
    Thread.sleep(3000);
	
	driver.findElement(By.xpath("//*[@id=\"mat-option-23\"]/span")).click();
	
	//Select_User_for_buyer
	
    Thread.sleep(2000);
	
	driver.findElement(By.xpath("//*[@id=\"mat-input-7\"]")).sendKeys(Buyer_Name);
	
	Thread.sleep(2000);
	
	//driver.findElement(By.xpath("//*[@id=\"mat-option-31\"]/span")).click();
	driver.findElement(By.xpath("//*[@id=\"mat-option-37\"]/span")).click();

	
	//mouse hover action
	
//	Thread.sleep(3000);
//	
//	WebElement ele = driver.findElement(By.xpath("//*[@id=\"mat-option-45\"]/span"));
//
//	//Creating object of an Actions class
//	
//	Thread.sleep(3000);
//	
//	Actions action = new Actions(driver);
//
//	//Performing the mouse hover action on the target element.
//	
//	Thread.sleep(3000);
//	
//	action.moveToElement(ele).perform();
//		
}
public void Select_User_Type_Seller(String Seller_Name) throws InterruptedException {
	
	Thread.sleep(3000);
	
	driver.findElement(By.xpath("//*[@id=\"mat-select-value-9\"]/span/span")).click();
	
	//Seller
	
    Thread.sleep(3000);
	
	driver.findElement(By.xpath("//*[@id=\"mat-option-24\"]/span")).click();
	
    //Select_User_for_seller
	
    Thread.sleep(3000);
	
	driver.findElement(By.xpath("//*[@id=\"mat-input-7\"]")).sendKeys(Seller_Name);
	
	Thread.sleep(2000);
	
	//driver.findElement(By.xpath("//*[@id=\"mat-option-45\"]/span")).click();
	driver.findElement(By.xpath("//*[@id=\"mat-option-30\"]/span")).click();
}


public void Invoice_Status_in_draft() throws InterruptedException {
	
	//Invoice status in dropdown arrow
	
	Thread.sleep(3000);
	
	driver.findElement(By.xpath("//*[@id=\"mat-select-4\"]/div/div[2]/div")).click();
		
	//Confirmed
		
		Thread.sleep(3000);
	
	driver.findElement(By.xpath("//*[@id=\"mat-option-13\"]/span")).click();
	
}

public void Search_by_invoice_GST_Num(String GSTno) throws InterruptedException {
	
	Thread.sleep(5000);
	
	//driver.findElement(By.xpath("//*[@id=\"mat-input-2\"]")).sendKeys(InvoiceN);
	
	//driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	
	//select drop-down list
	driver.findElement(By.xpath("//*[@id=\"mat-select-value-7\"]/span/span")).click();
    // Thread.sleep(5000);
     
     //select byuer
     driver.findElement(By.xpath("//*[@id=\"mat-option-20\"]/span")).click();

	//WebDriverWait wait = new WebDriverWait(driver, 10);
	 
	// WebElement dropdown = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id=\\\"mat-input-2\\\"]")));
	
	// ((JavascriptExecutor)driver).executeScript("arguments[0].click()",dropdown);
	
	driver.findElement(By.xpath("//*[@id=\"mat-input-4\"]")).sendKeys(GSTno+ "\n");

}


public void Search_by_seller_invoice_GST_Num(String GSTno) throws InterruptedException {
	
	Thread.sleep(5000);
	
	//driver.findElement(By.xpath("//*[@id=\"mat-input-2\"]")).sendKeys(InvoiceN);
	
	//driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	
	//select drop-down list
	driver.findElement(By.xpath("//*[@id=\"mat-select-8\"]/div/div[2]/div")).click();
    // Thread.sleep(5000);
     
     //select byuer
     driver.findElement(By.xpath("//*[@id=\"mat-option-24\"]/span")).click();

	//WebDriverWait wait = new WebDriverWait(driver, 10);
	 
	// WebElement dropdown = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id=\\\"mat-input-2\\\"]")));
	
	// ((JavascriptExecutor)driver).executeScript("arguments[0].click()",dropdown);
	
	driver.findElement(By.xpath("//*[@id=\"mat-input-5\"]")).sendKeys(GSTno+ "\n");

}
}
