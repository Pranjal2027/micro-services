package e_mandate;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import com.Xuriti.admin_panel_main.E_mandate_history;
import com.Xuriti.admin_panel_main.HomePage;
import com.Xuriti.admin_panel_main.Payment_History;

public class Items_per_page_20 {
	WebDriver driver;	
	@Test(priority=-1)
	public void Sign_up() throws InterruptedException {
	driver = new ChromeDriver();
	//driver.get("http://localhost:4200/#/auth/login");
	//driver.get("https://dev.xuriti.app/#/auth/login");
	HomePage HP = new HomePage(driver);
	HP.lauchApp();
	HP.admin_Login("krishna.kshirsagar@xuriti.com","Xuriti#10");		
	System.out.println("Logged in with valid crenditials");
}	
	@Test(priority=0)
	public void per_page() throws InterruptedException {
		E_mandate_history PH = new E_mandate_history(driver);
		PH.Items_per_page_20();
		driver.close();
	}
}
