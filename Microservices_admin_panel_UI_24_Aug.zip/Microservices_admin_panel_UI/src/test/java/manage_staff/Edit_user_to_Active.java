package manage_staff;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
import com.Xuriti.admin_panel_main.HomePage;
import com.Xuriti.admin_panel_main.Manage_Staff;

public class Edit_user_to_Active {
	WebDriver driver;	
	@Test(priority=-1)
	public void Sign_up() throws InterruptedException {
	driver = new ChromeDriver();
	//driver.get("http://localhost:4200/#/auth/login");
	//driver.get("https://dev.xuriti.app/#/auth/login");
	HomePage HP = new HomePage(driver);
	HP.lauchApp();
	HP.admin_Login("krishna.kshirsagar@xuriti.com","Xuriti#10");	
	System.out.println("Logged in with valid crenditials");
}	
	@Test(priority=0)
	public void Edit_user() throws InterruptedException {
		Manage_Staff MS = new Manage_Staff(driver);	
		MS.Edit_user_To_Active();
		Thread.sleep(2000);
		driver.close();
	}
}
