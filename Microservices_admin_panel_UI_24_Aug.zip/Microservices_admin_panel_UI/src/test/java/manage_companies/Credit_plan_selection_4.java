package manage_companies;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import com.Xuriti.admin_panel_main.HomePage;
import com.Xuriti.admin_panel_main.Manage_Companies_Edit;

public class Credit_plan_selection_4 {
	WebDriver driver;	
	@Test(priority=-1)
	public void Sign_up() throws InterruptedException {
	driver = new ChromeDriver();
	//driver.get("http://localhost:4200/#/auth/login");
	//driver.get("https://dev.xuriti.app/#/auth/login");
	HomePage HP = new HomePage(driver);
	HP.lauchApp();
	HP.admin_Login("krishna.kshirsagar@xuriti.com","Xuriti#10");		
	System.out.println("Logged in with valid crenditials");
}	
	@Test(priority=0)
	public void credit_plan_select() throws InterruptedException {
		Manage_Companies_Edit MC = new Manage_Companies_Edit(driver);	
		MC.Click_on_Credit_plan();
		MC.Add_Plan();
		MC.Credit_plan_name("Safal4");
		MC.Credit_Free_Period("90");
		MC.Number_of_Payment_Interval_4();		
		MC.Discount_Interval_1("30","5");
		MC.Discount_Interval_2("40","7");
		MC.Discount_Interval_3("50","9");
		MC.Discount_Interval_4("60","12");
		MC.Save_option_of_credit_plan();
	}
	}
