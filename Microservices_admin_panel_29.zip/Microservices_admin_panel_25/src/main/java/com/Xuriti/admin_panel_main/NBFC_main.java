package com.Xuriti.admin_panel_main;

//import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

public class NBFC_main {
WebDriver driver;
	
	
	public NBFC_main(WebDriver driver) throws InterruptedException {
		this.driver = driver;
	
		//Click on NBFC
				 
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("/html/body/app-root/app-dashboard/app-layout/mat-sidenav-container/mat-sidenav/div/app-sidebar/div/div/div[3]/mat-nav-list/mat-list-item[8]/span")).click(); 
								 
		//driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
				
}
public void Search_NBFC_Name(String NM) throws InterruptedException {
	
	//Click on search NBFC_name
	 
	Thread.sleep(3000);
	
	driver.findElement(By.xpath("//*[@id=\"mat-input-2\"]")).sendKeys(NM); 	
}
public void Search_NBFC_Active() throws InterruptedException {
	
	    //click on down arrow
		
	    Thread.sleep(3000);
	    
		driver.findElement(By.xpath("//*[@id=\"mat-select-2\"]/div/div[2]")).click(); 
		Thread.sleep(2000);

	    driver.findElement(By.xpath("//*[@id=\"mat-option-4\"]/span")).click();
	   		    	
}
public void Search_NBFC_InActive() throws InterruptedException {
	
    //click on down arrow
	
    Thread.sleep(3000);
    
	driver.findElement(By.xpath("//*[@id=\"mat-select-2\"]/div/div[2]")).click(); 	

    driver.findElement(By.xpath("//*[@id=\"mat-option-6\"]/span")).click();
   		    	
}
public void Search_NBFC_Pending() throws InterruptedException {
	
    //click on down arrow
	
    Thread.sleep(3000);
    
	driver.findElement(By.xpath("//*[@id=\"mat-select-2\"]/div/div[2]")).click(); 	

    driver.findElement(By.xpath("//*[@id=\"mat-option-5\"]")).click();
   		    	
}
public void Edit_Name(String NA) throws InterruptedException {
	//Edit user
		Thread.sleep(3000);
	    
		//driver.findElement(By.xpath("//*[@id=\"nbfc-list-page\"]/div/div[3]/table/tbody/tr[1]/td[6]/button[1]/span[1]/mat-icon")).click(); 	
		driver.findElement(By.xpath("//*[@id=\"nbfc-list-page\"]/div/div[3]/table/tbody/tr[7]/td[6]/button[1]/span[1]/mat-icon")).click(); 	
	    driver.findElement(By.id("mat-input-3")).clear();//nbfc name
	    
	    driver.findElement(By.id("mat-input-3")).sendKeys(NA);//nbfc name 
	    Thread.sleep(8000);

	    
	  //Save
	    
	    driver.findElement(By.xpath("//*[@id=\"add-nbfc-page\"]/div/mat-card/mat-card-content/form/div[3]/div/button")).click(); //admin
	 
	    Thread.sleep(3000);
		
		if(driver.getPageSource().contains("NBFC details updated successfully")){
			System.out.println("Mandatory msg displayed'NBFC details updated successfully'");
			}else{
			System.out.println("Mandatory msg not displayed");
			}
	    	
}
public void Edit_Email(String Em) throws InterruptedException {
	//Edit user
		Thread.sleep(3000);
	    
		//driver.findElement(By.xpath("//*[@id=\"nbfc-list-page\"]/div/div[3]/table/tbody/tr[1]/td[6]/button[1]/span[1]/mat-icon")).click(); 	
		//driver.findElement(By.xpath("//*[@id=\"nbfc-list-page\"]/div/div[3]/table/tbody/tr[7]/td[6]/button[1]/span[1]/mat-icon")).click(); 	
		driver.findElement(By.xpath("//*[@id=\"nbfc-list-page\"]/div/div[3]/table/tbody/tr[7]/td[6]/button[1]/span[1]/mat-icon")).click(); 
		driver.findElement(By.id("mat-input-4")).clear();//EmailId
	    
	    driver.findElement(By.id("mat-input-4")).sendKeys(Em);//EmailId 
	    
	  //Save
	    
	    driver.findElement(By.xpath("//*[@id=\"add-nbfc-page\"]/div/mat-card/mat-card-content/form/div[3]/div/button")).click(); //admin
	 
	    Thread.sleep(3000);
		
		if(driver.getPageSource().contains("NBFC details updated successfully")){
			System.out.println("Mandatory msg displayed'NBFC details updated successfully'");
			}else{
			System.out.println("Mandatory msg not displayed");
			}
	    	
}


public void Edit_MBL(String MN) throws InterruptedException {
	//Edit user
		Thread.sleep(3000);
	    
		//driver.findElement(By.xpath("//*[@id=\"nbfc-list-page\"]/div/div[3]/table/tbody/tr[1]/td[6]/button[1]/span[1]/mat-icon")).click(); 	
		driver.findElement(By.xpath("//*[@id=\"nbfc-list-page\"]/div/div[3]/table/tbody/tr[7]/td[6]/button[1]/span[1]/mat-icon")).click(); 	
	    driver.findElement(By.id("mat-input-5")).clear();//Mobile
	    
	    driver.findElement(By.id("mat-input-5")).sendKeys(MN);//Mobile
	    Thread.sleep(2000);
	    
	  //Save
	    
	    driver.findElement(By.xpath("//*[@id=\"add-nbfc-page\"]/div/mat-card/mat-card-content/form/div[3]/div/button")).click(); //admin
	 
	    Thread.sleep(3000);
		
		if(driver.getPageSource().contains("NBFC details updated successfully")){
			System.out.println("Mandatory msg displayed'NBFC details updated successfully'");
			}else{
			System.out.println("Mandatory msg not displayed");
			}
	    	
}
public void Edit_Add(String Ad) throws InterruptedException {
	//Edit user
		Thread.sleep(3000);
	    
		//driver.findElement(By.xpath("//*[@id=\"nbfc-list-page\"]/div/div[3]/table/tbody/tr[1]/td[6]/button[1]/span[1]/mat-icon")).click(); 	

		driver.findElement(By.xpath("//*[@id=\"nbfc-list-page\"]/div/div[3]/table/tbody/tr[7]/td[6]/button[1]/span[1]/mat-icon")).click(); 	

	    driver.findElement(By.id("mat-input-6")).clear();//Address
	    
	    driver.findElement(By.id("mat-input-6")).sendKeys(Ad);//Address
	    Thread.sleep(5000);
	    
	  //Save
	    
	    driver.findElement(By.xpath("//*[@id=\"add-nbfc-page\"]/div/mat-card/mat-card-content/form/div[3]/div/button")).click(); //admin
	 
	    Thread.sleep(3000);
		
		if(driver.getPageSource().contains("NBFC details updated successfully")){
			System.out.println("Mandatory msg displayed'NBFC details updated successfully'");
			}else{
			System.out.println("Mandatory msg not displayed");
			}
	    	
}
public void Edit_Dist(String Di) throws InterruptedException {
	//Edit user
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id=\"nbfc-list-page\"]/div/div[3]/table/tbody/tr[7]/td[6]/button[1]/span[1]/mat-icon")).click(); 	
		//driver.findElement(By.xpath("//*[@id=\"nbfc-list-page\"]/div/div[3]/table/tbody/tr[1]/td[6]/button[1]/span[1]/mat-icon")).click(); 	
		//driver.findElement(By.xpath("//*[@id=\"nbfc-list-page\"]/div/div[3]/table/tbody/tr[7]/td[6]/button[1]/span[1]/mat-icon")).click(); 	
	    driver.findElement(By.id("mat-input-7")).clear();//District
	    
	    driver.findElement(By.id("mat-input-7")).sendKeys(Di);//District
	    Thread.sleep(5000);
	    
	  //Save
	    
	    driver.findElement(By.xpath("//*[@id=\"add-nbfc-page\"]/div/mat-card/mat-card-content/form/div[3]/div/button")).click(); //admin
	 
	    Thread.sleep(3000);
		
		if(driver.getPageSource().contains("NBFC details updated successfully")){
			System.out.println("Mandatory msg displayed'NBFC details updated successfully'");
			}else{
			System.out.println("Mandatory msg not displayed");
			}
	    	
}
public void Edit_State(String St) throws InterruptedException {
	//Edit user
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id=\"nbfc-list-page\"]/div/div[3]/table/tbody/tr[7]/td[6]/button[1]/span[1]/mat-icon")).click(); 	
		//driver.findElement(By.xpath("//*[@id=\"nbfc-list-page\"]/div/div[3]/table/tbody/tr[1]/td[6]/button[1]/span[1]/mat-icon")).click(); 	
		Thread.sleep(5000);
		
	    driver.findElement(By.id("mat-input-8")).clear();//State
	    Thread.sleep(2000);
	    
	    
	    driver.findElement(By.id("mat-input-8")).sendKeys(St);//State
	    Thread.sleep(5000);
	    
	  //Save
	    
	    driver.findElement(By.xpath("//*[@id=\"add-nbfc-page\"]/div/mat-card/mat-card-content/form/div[3]/div/button")).click(); //admin
	 
	    Thread.sleep(3000);
		
		if(driver.getPageSource().contains("NBFC details updated successfully")){
			System.out.println("Mandatory msg displayed'NBFC details updated successfully'");
			}else{
			System.out.println("Mandatory msg not displayed");
			}
	    	
}
public void Edit_Pincode(String PN) throws InterruptedException {
	//Edit user
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id=\"nbfc-list-page\"]/div/div[3]/table/tbody/tr[7]/td[6]/button[1]/span[1]/mat-icon")).click(); 	
		//driver.findElement(By.xpath("//*[@id=\"nbfc-list-page\"]/div/div[3]/table/tbody/tr[1]/td[6]/button[1]/span[1]/mat-icon")).click(); 	

	    driver.findElement(By.id("mat-input-9")).clear();//Pincode
	    Thread.sleep(2000);
	    
	    driver.findElement(By.id("mat-input-9")).sendKeys(PN);//Pincode
	    Thread.sleep(2000);
	    
	  //Save
	    
	    driver.findElement(By.xpath("//*[@id=\"add-nbfc-page\"]/div/mat-card/mat-card-content/form/div[3]/div/button")).click(); //admin
	 
	    Thread.sleep(3000);
		
		if(driver.getPageSource().contains("NBFC details updated successfully")){
			System.out.println("Mandatory msg displayed'NBFC details updated successfully'");
			}else{
			System.out.println("Mandatory msg not displayed");
			}
	    	
}
public void Edit_Intrest(String It) throws InterruptedException {
	//Edit user
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@id=\"nbfc-list-page\"]/div/div[3]/table/tbody/tr[7]/td[6]/button[1]/span[1]/mat-icon")).click(); 	
		//driver.findElement(By.xpath("//*[@id=\"nbfc-list-page\"]/div/div[3]/table/tbody/tr[1]/td[6]/button[1]/span[1]/mat-icon")).click(); 	

	    driver.findElement(By.id("mat-input-10")).clear();//Intrest
	    Thread.sleep(5000);
	    
	    driver.findElement(By.id("mat-input-10")).sendKeys(It);//Intrest
	    Thread.sleep(5000);

	    
	  //Save
	    
	    driver.findElement(By.xpath("//*[@id=\"add-nbfc-page\"]/div/mat-card/mat-card-content/form/div[3]/div/button")).click(); //admin
	 
	    Thread.sleep(3000);
		
		if(driver.getPageSource().contains("NBFC details updated successfully")){
			System.out.println("Mandatory msg displayed'NBFC details updated successfully'");
			}else{
			System.out.println("Mandatory msg not displayed");
			}
	    	
}
public void Edit_Bank_Name(String BN) throws InterruptedException {
	//Edit user
		Thread.sleep(3000);
	    
		//driver.findElement(By.xpath("//*[@id=\"nbfc-list-page\"]/div/div[3]/table/tbody/tr[1]/td[6]/button[1]")).click(); 	
		driver.findElement(By.xpath("//*[@id=\"nbfc-list-page\"]/div/div[3]/table/tbody/tr[7]/td[6]/button[1]/span[1]/mat-icon")).click(); 	
	    driver.findElement(By.id("mat-input-13")).clear();//Bank_name
	    
	    driver.findElement(By.id("mat-input-13")).sendKeys(BN);//Bank_Name
	    Thread.sleep(5000);
	    
	  //Save
	    
	    driver.findElement(By.xpath("//*[@id=\"add-nbfc-page\"]/div/mat-card/mat-card-content/form/div[3]/div/button")).click(); //admin
	 
	    Thread.sleep(3000);
		
		if(driver.getPageSource().contains("NBFC details updated successfully")){
			System.out.println("Mandatory msg displayed'NBFC details updated successfully'");
			}else{
			System.out.println("Mandatory msg not displayed");
			}
	    	
}
public void Edit_Branch_Name(String BN) throws InterruptedException {
	//Edit user
		Thread.sleep(3000);
	    
		//driver.findElement(By.xpath("//*[@id=\"nbfc-list-page\"]/div/div[3]/table/tbody/tr[1]/td[6]/button[1]")).click(); 	
		driver.findElement(By.xpath("//*[@id=\"nbfc-list-page\"]/div/div[3]/table/tbody/tr[7]/td[6]/button[1]/span[1]/mat-icon")).click(); 	
	    driver.findElement(By.id("mat-input-12")).clear();//Branch_name
	    
	    driver.findElement(By.id("mat-input-12")).sendKeys(BN);//Branch_Name
	    Thread.sleep(5000);
	    
	  //Save
	    
	    driver.findElement(By.xpath("//*[@id=\"add-nbfc-page\"]/div/mat-card/mat-card-content/form/div[3]/div/button")).click(); //admin
	 
	    Thread.sleep(3000);
		
		if(driver.getPageSource().contains("NBFC details updated successfully")){
			System.out.println("Mandatory msg displayed'NBFC details updated successfully'");
			}else{
			System.out.println("Mandatory msg not displayed");
			}
	    	
}
public void Edit_Acc_H_Name(String AN) throws InterruptedException {
	//Edit user
		Thread.sleep(3000);
	    
		//driver.findElement(By.xpath("//*[@id=\"nbfc-list-page\"]/div/div[3]/table/tbody/tr[1]/td[6]/button[1]/span[1]/mat-icon")).click(); 	
		driver.findElement(By.xpath("//*[@id=\"nbfc-list-page\"]/div/div[3]/table/tbody/tr[7]/td[6]/button[1]/span[1]/mat-icon")).click(); 	
	    driver.findElement(By.id("mat-input-13")).clear();//Account_H_name
	    
	    driver.findElement(By.id("mat-input-13")).sendKeys(AN);//Account_H_Name
	    
	    Thread.sleep(5000);
	  //Save
	    
	    driver.findElement(By.xpath("//*[@id=\"add-nbfc-page\"]/div/mat-card/mat-card-content/form/div[3]/div/button/span[1]")).click(); //admin
	 
	    Thread.sleep(3000);
		
		if(driver.getPageSource().contains("NBFC details updated successfully")){
			System.out.println("Mandatory msg displayed'NBFC details updated successfully'");
			}else{
			System.out.println("Mandatory msg not displayed");
			}
	    	
}
public void Edit_Acc_No(String AN) throws InterruptedException {
	//Edit user
		Thread.sleep(3000);
	    
		//driver.findElement(By.xpath("//*[@id=\"nbfc-list-page\"]/div/div[3]/table/tbody/tr[1]/td[6]/button[1]/span[1]/mat-icon")).click(); 	
		driver.findElement(By.xpath("//*[@id=\"nbfc-list-page\"]/div/div[3]/table/tbody/tr[7]/td[6]/button[1]/span[1]/mat-icon")).click(); 	
	    driver.findElement(By.id("mat-input-14")).clear();//Account_Number
	    
	    driver.findElement(By.id("mat-input-14")).sendKeys(AN);//Account_Number
	    
	    Thread.sleep(5000);
	  //Save
	    
	    driver.findElement(By.xpath("//*[@id=\"add-nbfc-page\"]/div/mat-card/mat-card-content/form/div[3]/div/button/span[1]")).click(); //admin
	 
	    Thread.sleep(3000);
		
		if(driver.getPageSource().contains("NBFC details updated successfully")){
			System.out.println("Mandatory msg displayed'NBFC details updated successfully'");
			}else{
			System.out.println("Mandatory msg not displayed");
			}
	    	
}
public void Edit_IFSC_Code(String IF) throws InterruptedException {
	//Edit user
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id=\"nbfc-list-page\"]/div/div[3]/table/tbody/tr[7]/td[6]/button[1]/span[1]/mat-icon")).click(); 	 
		//driver.findElement(By.xpath("//*[@id=\"nbfc-list-page\"]/div/div[3]/table/tbody/tr[1]/td[6]/button[1]/span[1]/mat-icon")).click(); 	

	    driver.findElement(By.id("mat-input-15")).clear();//IFSC
	    
	    driver.findElement(By.id("mat-input-15")).sendKeys(IF);//IFSC
	    Thread.sleep(5000);
	    
	  //Save
	    
	    driver.findElement(By.xpath("//*[@id=\"add-nbfc-page\"]/div/mat-card/mat-card-content/form/div[3]/div/button")).click(); //admin
	 
	    Thread.sleep(3000);
		
		if(driver.getPageSource().contains("NBFC details updated successfully")){
			System.out.println("Mandatory msg displayed'NBFC details updated successfully'");
			}else{
			System.out.println("Mandatory msg not displayed");
			}
	    	
}
public void NBFC_Buyer_Mapping() throws InterruptedException {
	
	   //click on arrow
	   
	   Thread.sleep(2000);
	   
	   driver.findElement(By.xpath("//*[@id=\"nbfc-list-page\"]/div/div[3]/table/tbody/tr[2]/td[6]/button[2]/span[1]/mat-icon")).click();
	   	   
}
public void NBFC_Buyer_Mapping_ADD() throws InterruptedException {
	
	   //click on mapping
	   
	   Thread.sleep(2000);
	   
	   driver.findElement(By.xpath("//*[@id=\"nbfc-list-page\"]/div/div[3]/table/tbody/tr[2]/td[6]/button[2]/span[1]/mat-icon")).click();
	   	 
	   //click ADD
	   
	   Thread.sleep(2000);
	   
	   driver.findElement(By.xpath("//*[@id=\"nbfc-mapping-page\"]/div/div[2]/button[2]")).click();

	   //mapping name
	   
       Thread.sleep(2000);
	   
	   driver.findElement(By.xpath("//*[@id=\"mat-input-5\"]")).sendKeys("bajaj");
	   
	   Thread.sleep(1000);
	   
	   driver.findElement(By.xpath("//*[@id=\"mat-option-19\"]/span")).sendKeys(Keys.ENTER);
	   
	 //*[@id="nbfc-mapping-dialog"]/mat-dialog-content/form/div/button[1]/span[1]
	   
	   //Map

     Thread.sleep(2000);
	   
	   driver.findElement(By.xpath("//*[@id=\"nbfc-mapping-dialog\"]/mat-dialog-content/form/div/button[1]/span[1]")).click();

	   Thread.sleep(3000);
		
		if(driver.getPageSource().contains("Company is mapped with NBFC successfully.")){
			System.out.println("Mandatory msg displayed'Company is mapped with NBFC successfully.'");
			}else{
			System.out.println("Mandatory msg not displayed");
			}
	   

}
public void Items_per_page_15() throws InterruptedException {
	//click on arrow
	   
	   Thread.sleep(2000);
	   
	   driver.findElement(By.xpath("//*[@id=\"mat-select-6\"]/div/div[2]")).click();
	
     //click on 20
	   
	   Thread.sleep(2000);
	   
	   driver.findElement(By.xpath("//*[@id=\"mat-option-12\"]/span")).click();	   
}
public void Items_per_page_50() throws InterruptedException {
	//click on arrow
	   
	   Thread.sleep(2000);
	   
	   driver.findElement(By.xpath("//*[@id=\"mat-select-6\"]/div/div[2]")).click();
	   
     //click on 50
	   
	   Thread.sleep(2000);
	   
	   driver.findElement(By.xpath("//*[@id=\"mat-option-13\"]/span")).click();	   
}
public void Next_Page_click() throws InterruptedException {
	
	   //click on arrow
	   
	   Thread.sleep(2000);
	   
	   driver.findElement(By.xpath("//*[@id=\"nbfc-list-page\"]/div/div[3]/mat-paginator/div/div/div[2]/button[3]/span[1]/svg")).click();	   	   
}

   public void add_NBFC(String N_name, String N_email, String N_mobile_no, String N_address, String N_disrict, String N_state, String N_pin, String N_interest, String B_name, String B_branchname, String B_holdername, String B_accountNo, String B_ifsc) throws InterruptedException
   {
	   //click on add nbfc
	   
	   Thread.sleep(3000);
	  driver.findElement(By.xpath("//*[@id=\"nbfc-list-page\"]/div/div[1]/button/span[1]")).click();
	  
	  Thread.sleep(2000);
	  
	  //Basic details Name
	  
	  //Enter name
	  
	  driver.findElement(By.id("mat-input-3")).sendKeys(N_name);
	  Thread.sleep(2000);
	  
	  //select status
	  
	  //click on drop-down list
	  driver.findElement(By.xpath("//*[@id=\"mat-select-6\"]/div/div[2]")).click();
	  Thread.sleep(2000);
    
	  //select pending 
	  driver.findElement(By.xpath("//*[@id=\"mat-option-11\"]/span")).click();
	  
	  //Enter email
	  driver.findElement(By.id("mat-input-4")).sendKeys(N_email);
	  Thread.sleep(2000);
	  
	  //Enter mobile no
	  driver.findElement(By.id("mat-input-5")).sendKeys(N_mobile_no);
	  Thread.sleep(2000);

	//Enter Address
	  driver.findElement(By.id("mat-input-6")).sendKeys(N_address);
	  Thread.sleep(2000);
	  
	//Enter disrict
	  driver.findElement(By.id("mat-input-7")).sendKeys(N_disrict);
	  Thread.sleep(2000);
	  
	//Enter state
	  driver.findElement(By.id("mat-input-8")).sendKeys(N_state);
	  Thread.sleep(2000);
	  
	//Enter pincode
	  driver.findElement(By.id("mat-input-9")).sendKeys(N_pin);
	  Thread.sleep(2000);
	  
	//Enter interest
	  driver.findElement(By.id("mat-input-10")).sendKeys(N_interest);
	  Thread.sleep(2000);
	  
	  //Bank details
	  
	  //Enter bank name
	  driver.findElement(By.id("mat-input-11")).sendKeys(B_name);
	  Thread.sleep(2000);
	  
	 //Enter bank branch name
	  driver.findElement(By.id("mat-input-12")).sendKeys(B_branchname);
	  Thread.sleep(2000);
	  
	//Enter bank holder name
	  driver.findElement(By.id("mat-input-13")).sendKeys(B_holdername);
	  Thread.sleep(2000);
	  
	//Enter bank account NO
	  driver.findElement(By.id("mat-input-14")).sendKeys(B_accountNo);
	  Thread.sleep(2000);
	  
	//Enter bank ifsc code
	  driver.findElement(By.id("mat-input-15")).sendKeys(B_ifsc);
	  Thread.sleep(2000);
	  driver.manage().window().maximize();
	  
	  
	  //click on save button
	  
	  driver.findElement(By.xpath("//*[@id=\"add-nbfc-page\"]/div/mat-card/mat-card-content/form/div[3]/div/button/span[1]")).click();

}
   public void nbfc_status_blank(String N_name, String N_email, String N_mobile_no, String N_address, String N_disrict, String N_state, String N_pin, String N_interest, String B_name, String B_branchname, String B_holdername, String B_accountNo, String B_ifsc) throws InterruptedException
   {
	   //click on add nbfc
	   
	   Thread.sleep(3000);
	  driver.findElement(By.xpath("//*[@id=\"nbfc-list-page\"]/div/div[1]/button/span[1]")).click();
	  
	  Thread.sleep(2000);
	  
	  //Basic details Name
	  
	  //Enter name
	  
	  driver.findElement(By.id("mat-input-3")).sendKeys(N_name);
	  Thread.sleep(2000);
	  
	  //select status
	  
//	  //click on drop-down list
//	  driver.findElement(By.xpath("//*[@id=\"mat-select-6\"]/div/div[2]")).click();
//	  Thread.sleep(2000);
//    
//	  //select pending 
//	  driver.findElement(By.xpath("//*[@id=\"mat-option-11\"]/span")).click();
//	  
	  //Enter email
	  driver.findElement(By.id("mat-input-4")).sendKeys(N_email);
	  Thread.sleep(2000);
	  
	  //Enter mobile no
	  driver.findElement(By.id("mat-input-5")).sendKeys(N_mobile_no);
	  Thread.sleep(2000);

	//Enter Address
	  driver.findElement(By.id("mat-input-6")).sendKeys(N_address);
	  Thread.sleep(2000);
	  
	//Enter disrict
	  driver.findElement(By.id("mat-input-7")).sendKeys(N_disrict);
	  Thread.sleep(2000);
	  
	//Enter state
	  driver.findElement(By.id("mat-input-8")).sendKeys(N_state);
	  Thread.sleep(2000);
	  
	//Enter pincode
	  driver.findElement(By.id("mat-input-9")).sendKeys(N_pin);
	  Thread.sleep(2000);
	  
	//Enter interest
	  driver.findElement(By.id("mat-input-10")).sendKeys(N_interest);
	  Thread.sleep(2000);
	  
	  //Bank details
	  
	  //Enter bank name
	  driver.findElement(By.id("mat-input-11")).sendKeys(B_name);
	  Thread.sleep(2000);
	  
	 //Enter bank branch name
	  driver.findElement(By.id("mat-input-12")).sendKeys(B_branchname);
	  Thread.sleep(2000);
	  
	//Enter bank holder name
	  driver.findElement(By.id("mat-input-13")).sendKeys(B_holdername);
	  Thread.sleep(2000);
	  
	//Enter bank account NO
	  driver.findElement(By.id("mat-input-14")).sendKeys(B_accountNo);
	  Thread.sleep(2000);
	  
	//Enter bank ifsc code
	  driver.findElement(By.id("mat-input-15")).sendKeys(B_ifsc);
	  Thread.sleep(2000);
	  driver.manage().window().maximize();
	  
	  
	  //click on save button
	  
	  driver.findElement(By.xpath("//*[@id=\"add-nbfc-page\"]/div/mat-card/mat-card-content/form/div[3]/div/button/span[1]")).click();
   }

   public void nbfc_status_active(String N_name, String N_email, String N_mobile_no, String N_address, String N_disrict, String N_state, String N_pin, String N_interest, String B_name, String B_branchname, String B_holdername, String B_accountNo, String B_ifsc) throws InterruptedException
   {
	   //click on add nbfc
	   
	   Thread.sleep(3000);
	  driver.findElement(By.xpath("//*[@id=\"nbfc-list-page\"]/div/div[1]/button/span[1]")).click();
	  
	  Thread.sleep(2000);
	  
	  //Basic details Name
	  
	  //Enter name
	  
	  driver.findElement(By.id("mat-input-3")).sendKeys(N_name);
	  Thread.sleep(2000);
	  
	  //select status
	  
	  //click on drop-down list
	  driver.findElement(By.xpath("//*[@id=\"mat-select-6\"]/div/div[2]")).click();
	  Thread.sleep(2000);
    
	  //select active 
	  driver.findElement(By.xpath("//*[@id=\"mat-option-10\"]/span")).click();
	  
	  //Enter email
	  driver.findElement(By.id("mat-input-4")).sendKeys(N_email);
	  Thread.sleep(2000);
	  
	  //Enter mobile no
	  driver.findElement(By.id("mat-input-5")).sendKeys(N_mobile_no);
	  Thread.sleep(2000);

	//Enter Address
	  driver.findElement(By.id("mat-input-6")).sendKeys(N_address);
	  Thread.sleep(2000);
	  
	//Enter disrict
	  driver.findElement(By.id("mat-input-7")).sendKeys(N_disrict);
	  Thread.sleep(2000);
	  
	//Enter state
	  driver.findElement(By.id("mat-input-8")).sendKeys(N_state);
	  Thread.sleep(2000);
	  
	//Enter pincode
	  driver.findElement(By.id("mat-input-9")).sendKeys(N_pin);
	  Thread.sleep(2000);
	  
	//Enter interest
	  driver.findElement(By.id("mat-input-10")).sendKeys(N_interest);
	  Thread.sleep(2000);
	  
	  //Bank details
	  
	  //Enter bank name
	  driver.findElement(By.id("mat-input-11")).sendKeys(B_name);
	  Thread.sleep(2000);
	  
	 //Enter bank branch name
	  driver.findElement(By.id("mat-input-12")).sendKeys(B_branchname);
	  Thread.sleep(2000);
	  
	//Enter bank holder name
	  driver.findElement(By.id("mat-input-13")).sendKeys(B_holdername);
	  Thread.sleep(2000);
	  
	//Enter bank account NO
	  driver.findElement(By.id("mat-input-14")).sendKeys(B_accountNo);
	  Thread.sleep(2000);
	  
	//Enter bank ifsc code
	  driver.findElement(By.id("mat-input-15")).sendKeys(B_ifsc);
	  Thread.sleep(2000);
	  driver.manage().window().maximize();
	  
	  
	  //click on save button
	  
	  driver.findElement(By.xpath("//*[@id=\"add-nbfc-page\"]/div/mat-card/mat-card-content/form/div[3]/div/button/span[1]")).click();
   }
   
   public void nbfc_status_inactive(String N_name, String N_email, String N_mobile_no, String N_address, String N_disrict, String N_state, String N_pin, String N_interest, String B_name, String B_branchname, String B_holdername, String B_accountNo, String B_ifsc) throws InterruptedException
   {
	   //click on add nbfc
	   
	   Thread.sleep(3000);
	  driver.findElement(By.xpath("//*[@id=\"nbfc-list-page\"]/div/div[1]/button/span[1]")).click();
	  
	  Thread.sleep(2000);
	  
	  //Basic details Name
	  
	  //Enter name
	  
	  driver.findElement(By.id("mat-input-3")).sendKeys(N_name);
	  Thread.sleep(2000);
	  
	  //select status
	  
	  //click on drop-down list
	  driver.findElement(By.xpath("//*[@id=\"mat-select-6\"]/div/div[2]")).click();
	  Thread.sleep(2000);
    
	  //select active 
	  driver.findElement(By.xpath("//*[@id=\"mat-option-12\"]/span")).click();
	  
	  //Enter email
	  driver.findElement(By.id("mat-input-4")).sendKeys(N_email);
	  Thread.sleep(2000);
	  
	  //Enter mobile no
	  driver.findElement(By.id("mat-input-5")).sendKeys(N_mobile_no);
	  Thread.sleep(2000);

	//Enter Address
	  driver.findElement(By.id("mat-input-6")).sendKeys(N_address);
	  Thread.sleep(2000);
	  
	//Enter disrict
	  driver.findElement(By.id("mat-input-7")).sendKeys(N_disrict);
	  Thread.sleep(2000);
	  
	//Enter state
	  driver.findElement(By.id("mat-input-8")).sendKeys(N_state);
	  Thread.sleep(2000);
	  
	//Enter pincode
	  driver.findElement(By.id("mat-input-9")).sendKeys(N_pin);
	  Thread.sleep(2000);
	  
	//Enter interest
	  driver.findElement(By.id("mat-input-10")).sendKeys(N_interest);
	  Thread.sleep(2000);
	  
	  //Bank details
	  
	  //Enter bank name
	  driver.findElement(By.id("mat-input-11")).sendKeys(B_name);
	  Thread.sleep(2000);
	  
	 //Enter bank branch name
	  driver.findElement(By.id("mat-input-12")).sendKeys(B_branchname);
	  Thread.sleep(2000);
	  
	//Enter bank holder name
	  driver.findElement(By.id("mat-input-13")).sendKeys(B_holdername);
	  Thread.sleep(2000);
	  
	//Enter bank account NO
	  driver.findElement(By.id("mat-input-14")).sendKeys(B_accountNo);
	  Thread.sleep(2000);
	  
	//Enter bank ifsc code
	  driver.findElement(By.id("mat-input-15")).sendKeys(B_ifsc);
	  Thread.sleep(2000);
	  driver.manage().window().maximize();
	  
	  
	  //click on save button
	  
	  driver.findElement(By.xpath("//*[@id=\"add-nbfc-page\"]/div/mat-card/mat-card-content/form/div[3]/div/button/span[1]")).click();
   }
   
   public void blank_all_fields_add_NBFC(String N_name, String N_email, String N_mobile_no, String N_address, String N_disrict, String N_state, String N_pin, String N_interest, String B_name, String B_branchname, String B_holdername, String B_accountNo, String B_ifsc) throws InterruptedException
   {
	   //click on add nbfc
	   
	   Thread.sleep(3000);
	  driver.findElement(By.xpath("//*[@id=\"nbfc-list-page\"]/div/div[1]/button/span[1]")).click();
	  
	  Thread.sleep(2000);
	  
	  //Basic details Name
	  
	  //Enter name
	  
	  driver.findElement(By.id("mat-input-3")).sendKeys(N_name);
	  Thread.sleep(2000);
	  
//	  //select status
//	  
//	  //click on drop-down list
//	  driver.findElement(By.xpath("//*[@id=\"mat-select-6\"]/div/div[2]")).click();
//	  Thread.sleep(2000);
//    
//	  //select pending 
//	  driver.findElement(By.xpath("//*[@id=\"mat-option-11\"]/span")).click();
	  
	  //Enter email
	  driver.findElement(By.id("mat-input-4")).sendKeys(N_email);
	  Thread.sleep(2000);
	  
	  //Enter mobile no
	  driver.findElement(By.id("mat-input-5")).sendKeys(N_mobile_no);
	  Thread.sleep(2000);

	//Enter Address
	  driver.findElement(By.id("mat-input-6")).sendKeys(N_address);
	  Thread.sleep(2000);
	  
	//Enter disrict
	  driver.findElement(By.id("mat-input-7")).sendKeys(N_disrict);
	  Thread.sleep(2000);
	  
	//Enter state
	  driver.findElement(By.id("mat-input-8")).sendKeys(N_state);
	  Thread.sleep(2000);
	  
	//Enter pincode
	  driver.findElement(By.id("mat-input-9")).sendKeys(N_pin);
	  Thread.sleep(2000);
	  
	//Enter interest
	  driver.findElement(By.id("mat-input-10")).sendKeys(N_interest);
	  Thread.sleep(2000);
	  
	  //Bank details
	  
	  //Enter bank name
	  driver.findElement(By.id("mat-input-11")).sendKeys(B_name);
	  Thread.sleep(2000);
	  
	 //Enter bank branch name
	  driver.findElement(By.id("mat-input-12")).sendKeys(B_branchname);
	  Thread.sleep(2000);
	  
	//Enter bank holder name
	  driver.findElement(By.id("mat-input-13")).sendKeys(B_holdername);
	  Thread.sleep(2000);
	  
	//Enter bank account NO
	  driver.findElement(By.id("mat-input-14")).sendKeys(B_accountNo);
	  Thread.sleep(2000);
	  
	//Enter bank ifsc code
	  driver.findElement(By.id("mat-input-15")).sendKeys(B_ifsc);
	  Thread.sleep(2000);
	  driver.manage().window().maximize();
	  
	  
	  //click on save button
	  
	  driver.findElement(By.xpath("//*[@id=\"add-nbfc-page\"]/div/mat-card/mat-card-content/form/div[3]/div/button/span[1]")).click();

}


}


