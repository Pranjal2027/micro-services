package com.Xuriti.admin_panel_main;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Payment_History {
WebDriver driver;
	
	
	public Payment_History  (WebDriver driver) throws InterruptedException {
		this.driver = driver;
	
		//Click on Payment History
				 
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("/html/body/app-root/app-dashboard/app-layout/mat-sidenav-container/mat-sidenav/div/app-sidebar/div/div/div[3]/mat-nav-list/mat-list-item[6]/span/mat-icon")).click(); 
	
		//click on calander
		// driver.findElement(By.xpath("//*[@id=\"paymenthistory-page\"]/div/mat-form-field[3]/div/div[1]/div[4]/mat-datepicker-toggle/button/span[1]/svg")).click();	
		
		
		
}
public void Search_by_Invoice_No(String InvNo) throws InterruptedException {
    Thread.sleep(2000);
      
   driver.findElement(By.xpath("")).sendKeys(InvNo); 	
}
public void Search_by_Invoice_Date(String InvDate) throws InterruptedException {
     //click on calander
	 driver.findElement(By.xpath("//*[@id=\"paymenthistory-page\"]/div/mat-form-field[3]")).click();
    
	 //click on date
	 Thread.sleep(2000);
      
   driver.findElement(By.xpath("//*[@id=\"mat-datepicker-0\"]/div/mat-month-view/table/tbody/tr[5]/td[4]/button/div[1]")).sendKeys(InvDate); 	
}
public void Search_by_Payment_Date(String PayDate) throws InterruptedException {
	
    Thread.sleep(2000);
      //click on date
   driver.findElement(By.xpath("//*[@id=\"mat-datepicker-0\"]/div/mat-month-view/table/tbody/tr[5]/td[4]/button/div[1]")).sendKeys(PayDate); 	
}
public void Change_status_to_Pending() throws InterruptedException {

    //click on change status
	
	Thread.sleep(2000);
      
  // driver.findElement(By.xpath("//*[@id=\"paymenthistory-page\"]/div/table/tbody/tr[1]/td[10]/button/span[1]/mat-icon")).click(); 	
	driver.findElement(By.xpath("//*[@id=\"paymenthistory-page\"]/div/table/tbody/tr[1]/td[8]/button/span[1]/mat-icon")).click(); 
   //click change payment status
   
   Thread.sleep(2000);
   
  // driver.findElement(By.xpath("//*[@id=\"mat-select-value-7\"]/span")).click();
   driver.findElement(By.xpath("//*[@id=\"mat-select-6\"]/div")).click();
   //click on Pending
   
   Thread.sleep(2000);
   
   driver.findElement(By.xpath("//*[@id=\"mat-option-9\"]/span")).click();
   
    //submit
   
  // Thread.sleep(2000);
   
  // driver.findElement(By.xpath("//*[@id=\"paymenthistory-dialog\"]/mat-dialog-content/form/div/button[1]/span[1]")).click();
   
}
public void Change_status_to_Paid() throws InterruptedException {

    //click on change status
	
	Thread.sleep(2000);
      
   driver.findElement(By.xpath("//*[@id=\"paymenthistory-page\"]/div/table/tbody/tr[1]/td[8]/button/span[1]/mat-icon")).click(); 	

   //click change payment status
   
   Thread.sleep(2000);
   
   driver.findElement(By.xpath("//*[@id=\"mat-select-6\"]/div")).click();
   
   //click on Paid
   
   Thread.sleep(2000);
   
   driver.findElement(By.xpath("//*[@id=\"mat-option-10\"]/span")).click();
   
    //submit
   
  // Thread.sleep(2000);
   
  // driver.findElement(By.xpath("//*[@id=\"paymenthistory-dialog\"]/mat-dialog-content/form/div/button[1]/span[1]")).click();
   
}
public void Change_status_to_Failure() throws InterruptedException {

    //click on change status
	
	Thread.sleep(2000);
      
   driver.findElement(By.xpath("//*[@id=\"paymenthistory-page\"]/div/table/tbody/tr[1]/td[8]/button/span[1]/mat-icon")).click(); 	

   //click change payment status
   
   Thread.sleep(2000);
   
   driver.findElement(By.xpath("//*[@id=\"mat-select-6\"]/div")).click();
   
   //click on failure
   
   Thread.sleep(2000);
   
   driver.findElement(By.xpath("//*[@id=\"mat-option-11\"]/span")).click();
   
    //submit
   
  // Thread.sleep(2000);
   
  // driver.findElement(By.xpath("//*[@id=\"paymenthistory-dialog\"]/mat-dialog-content/form/div/button[1]/span[1]")).click();
   
}
public void Items_per_page_10() throws InterruptedException {
	
	//click on arrow
	   
	   Thread.sleep(2000);
	   
	   driver.findElement(By.xpath("//*[@id=\"mat-select-4\"]/div")).click();
	
     //click on 10
	   
	   Thread.sleep(2000);
	   
	   driver.findElement(By.xpath("//*[@id=\"mat-option-6\"]/span")).click();
	 
	   
}
public void Items_per_page_50() throws InterruptedException {
	//click on arrow
	   
	   Thread.sleep(2000);
	   
	   driver.findElement(By.xpath("//*[@id=\"mat-select-4\"]/div/div[2]")).click();
	   
     //click on 50
	   
	   Thread.sleep(2000);
	   
	   driver.findElement(By.xpath("//*[@id=\"mat-option-8\"]/span")).click();
	 
	   
}
public void Next_Page_click() throws InterruptedException {
	//click on arrow
	   
	   Thread.sleep(2000);
	   
	   driver.findElement(By.xpath("/html/body/app-root/app-paymenthistory/app-layout/mat-sidenav-container/mat-sidenav-content/div/div/div/mat-paginator/div/div/div[2]/button[3]/span[1]/svg")).click();
	   	   
}
}


