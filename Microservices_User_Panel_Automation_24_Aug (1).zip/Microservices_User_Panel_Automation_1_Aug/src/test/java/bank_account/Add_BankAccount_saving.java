package bank_account;

import org.testng.annotations.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import com.Xuriti.New.elevenApril.Bank_Account_saving;
import com.Xuriti.New.elevenApril.Main_LoginPage;

public class Add_BankAccount_saving {
	public class Add_BankAccount {
		WebDriver driver;
		@Test(priority=-1)
		public void Main_Login() throws InterruptedException {
			driver = new ChromeDriver();
			//driver.get("http://localhost:4200/#/auth/login");
			driver.get("https://dev.xuriti.app/#/auth/login");
			driver.manage().window().maximize();
			Main_LoginPage li=new Main_LoginPage(driver);
			//li.EmailPass("shraddha.b.techtrail@gmail.com","Shraddha#10");	
			li.EmailPass("varsha.patil@tech-trail.com","Xuriti#10");				
	}
		@Test(priority=0)
		public void Add_BankAccount_saving() throws InterruptedException {
			Bank_Account_saving Ba= new Bank_Account_saving(driver);	
			Ba.Bank_Details("Yes Bank","9876543245","Shaji","Shivaji Nagar","YESC0001805");	
			Ba.Pop_Up_msg_for_bank_account_creation();
			driver.close();
		}
	}
}
