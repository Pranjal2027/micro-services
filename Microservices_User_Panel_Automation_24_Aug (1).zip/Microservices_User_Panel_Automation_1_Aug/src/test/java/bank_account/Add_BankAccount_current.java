package bank_account;

import org.testng.annotations.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import com.Xuriti.New.elevenApril.Bank_Account_current;
import com.Xuriti.New.elevenApril.Main_LoginPage;

public class Add_BankAccount_current {
	WebDriver driver;
	@Test(priority=-1)
	public void Main_Login() throws InterruptedException {
		driver = new ChromeDriver();
		//driver.get("http://localhost:4200/#/auth/login");
		driver.get("https://dev.xuriti.app/#/auth/login");
		driver.manage().window().maximize();
		Main_LoginPage li=new Main_LoginPage(driver);
		li.EmailPass("varsha.patil@tech-trail.com","Xuriti#10");	
	//	li.EmailPass("krishna.kshirsagar@tech-trail.com ","Krishh@123");	
		//li.EmailPass("abhishek.parihar@xuriti.com","Abhishek21@");		

		//Thread.sleep(3000); 
		
		// driver.findElement(By.xpath("//*[@id=\"mat-dialog-0\"]/app-info-dialog/mat-dialog-actions/button")).click(); //Click on Manage user

		//driver.findElement(By.xpath("//*[@id=\"mat-dialog-2\"]/app-info-dialog/mat-dialog-actions/button/span[1]")).click();		
		 }
	@Test(priority=0)
	public void Add_BankAccount_current() throws InterruptedException {
		Bank_Account_current Ba= new Bank_Account_current(driver);	
		Ba.Bank_Details("Bank Of Maharashtra","7432156789","Dhoni j","Ranchi","DHBK0001805");	
		Ba.Pop_Up_msg_for_bank_account_creation();
		driver.close();
	}
}
