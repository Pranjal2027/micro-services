package reports;

import org.testng.annotations.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
import com.Xuriti.New.elevenApril.Main_LoginPage;
import com.Xuriti.New.elevenApril.Reports;

public class Search_by_Invoice_Status_Paid {
	WebDriver driver;
	@Test(priority=-1)
	public void Main_Login() throws InterruptedException {
		driver = new ChromeDriver();
		//driver.get("http://localhost:4200/#/auth/login");
		driver.get("https://dev.xuriti.app/#/auth/login");
		driver.manage().window().maximize();
		Main_LoginPage li=new Main_LoginPage(driver);
		li.EmailPass("varsha.patil@tech-trail.com","Xuriti#10");		
}
	@Test(priority=0)
	public void Reports_Search_by_Invoice_Status_Paid() throws InterruptedException {
		Reports PH= new Reports  (driver);
		PH.click_on_reports();
		PH.Search_By_Invoice_status_Paid();
		
		//driver.close();
}
}

