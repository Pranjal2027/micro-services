package payment_History;

import org.testng.annotations.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
import com.Xuriti.New.elevenApril.Main_LoginPage;
import com.Xuriti.New.elevenApril.Payment_History_Page;

public class TC_pAYMENT_hISTORY {
	WebDriver driver;
	@Test(priority=-1)
	public void Main_Login() throws InterruptedException {
		driver = new ChromeDriver();
		//driver.get("http://localhost:4200/#/auth/login");
		driver.get("https://dev.xuriti.app/#/auth/login");
		driver.manage().window().maximize();
		Main_LoginPage li=new Main_LoginPage(driver);
		li.EmailPass("varsha.patil@tech-trail.com","Xuriti#10");		
}
	@Test(priority=0)
	public void Payment_History() throws InterruptedException {
		Payment_History_Page PH= new Payment_History_Page (driver);	
		PH.Payment_History();
		System.out.println("Purchase Sales dasboard Present,Clickable,Displays purchase dashboard");			
        driver.close();
	}
}

