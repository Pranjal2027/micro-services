package manage_staff;

import org.testng.annotations.Test;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.Xuriti.admin_panel_main.HomePage;
import com.Xuriti.admin_panel_main.Manage_Staff;

public class Search_user_by_name {
	WebDriver driver;	
	@Test(priority=-1)
	public void Sign_up() throws InterruptedException {
	driver = new ChromeDriver();
	//driver.get("http://localhost:4200/#/auth/login");
	//driver.get("https://dev.xuriti.app/#/auth/login");
	HomePage HP = new HomePage(driver);
	HP.lauchApp();
	HP.admin_Login("krishna.kshirsagar@xuriti.com","Xuriti#10");	
	System.out.println("Logged in with valid crenditials");
}	
	@Test(priority=0)
	public void Search() throws InterruptedException {
		Manage_Staff MS = new Manage_Staff(driver);	
		MS.Search_by_user_name("Krishna");
		driver.close();
	}
}
