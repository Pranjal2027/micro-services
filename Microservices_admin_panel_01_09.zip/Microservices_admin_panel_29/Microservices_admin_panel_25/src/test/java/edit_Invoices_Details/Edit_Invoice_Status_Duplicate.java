package edit_Invoices_Details;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
import com.Xuriti.admin_panel_main.HomePage;
import com.Xuriti.admin_panel_main.Invoices;


public class Edit_Invoice_Status_Duplicate{
	WebDriver driver;	
	@Test(priority=-1)
	public void Sign_up() throws InterruptedException {
	driver = new ChromeDriver();
	//driver.get("http://localhost:4200/#/auth/login");
	//driver.get("https://dev.xuriti.app/#/auth/login");
	HomePage HP = new HomePage(driver);
	HP.lauchApp();
	HP.admin_Login("krishna.kshirsagar@xuriti.com","Xuriti#10");		
		
	System.out.println("Logged in with valid crenditials");
}	
	@Test(priority=0)
	public void Invoice_Edit() throws InterruptedException {
		Invoices IG = new Invoices (driver);
		IG.Invoice_Status_Duplicate();
		driver.close();
	}
	}
