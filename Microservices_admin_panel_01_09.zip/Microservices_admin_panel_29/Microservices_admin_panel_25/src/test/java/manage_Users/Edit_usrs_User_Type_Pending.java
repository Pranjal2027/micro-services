package manage_Users;

import org.testng.annotations.Test;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.Xuriti.admin_panel_main.HomePage;
import com.Xuriti.admin_panel_main.Manage_Users;

public class Edit_usrs_User_Type_Pending {
	WebDriver driver;	
	@Test(priority=-1)
	public void Sign_up() throws InterruptedException {
	driver = new ChromeDriver();
	//driver.get("http://localhost:4200/#/auth/login");
	//driver.get("https://dev.xuriti.app/#/auth/login");
	HomePage HP = new HomePage(driver);
	HP.lauchApp();
	HP.admin_Login("krishna.kshirsagar@xuriti.com","Xuriti#10");		
	System.out.println("Logged in with valid crenditials");
}	
	@Test(priority=0)
	public void Edit_user_type_pending() throws InterruptedException {
		Manage_Users MU = new Manage_Users(driver);	
		MU.Edit_user_Details();
		MU.Select_User_Status_Pending();
		driver.close();
	}
}
