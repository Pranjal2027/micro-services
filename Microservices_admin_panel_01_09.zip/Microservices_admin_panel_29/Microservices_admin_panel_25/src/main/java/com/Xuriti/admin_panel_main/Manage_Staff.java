package com.Xuriti.admin_panel_main;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Manage_Staff {
WebDriver driver;
	
	
	public Manage_Staff  (WebDriver driver) throws InterruptedException {
		this.driver = driver;
	
		//Click on Manage_Staff
				 
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("/html/body/app-root/app-dashboard/app-layout/mat-sidenav-container/mat-sidenav/div/app-sidebar/div/div/div[3]/mat-nav-list/mat-list-item[5]/span")).click(); 
									 
		//driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
				
}
public void Search_by_user_name(String username) throws InterruptedException {
	
	//Click on Edit_Users
	
	
	 
	Thread.sleep(3000);
	
	driver.findElement(By.xpath("//*[@id=\"mat-input-2\"]")).sendKeys(username); 	
}
public void Add_user_Xuriti_Admin(String FN,String LN, String email, String MN) throws InterruptedException {
	
	    //click on add user
		
	    Thread.sleep(3000);
	    
		driver.findElement(By.xpath("//*[@id=\"stafflist-page\"]/div/button/span[1]")).click(); 	

		Thread.sleep(2000);
		
		driver.findElement(By.id("mat-input-4")).sendKeys(FN);//FirstName
		
		
        Thread.sleep(2000);
	    
	    driver.findElement(By.id("mat-input-5")).sendKeys(LN);//LastName 
	    
	    Thread.sleep(2000);
	    
	    driver.findElement(By.id("mat-input-6")).sendKeys(email);//Email 
	    
	    Thread.sleep(2000);
	    
	    driver.findElement(By.id("mat-input-7")).sendKeys(MN);//MN 
	    
	    //Select user type xuriti admin
		
	   	Thread.sleep(3000);
	   	    
	   	driver.findElement(By.xpath("//*[@id=\"mat-select-8\"]/div/div[2]")).click(); 
	   	
	   	Thread.sleep(3000);
   	    
	   	driver.findElement(By.xpath("//*[@id=\"mat-option-13\"]/span")).click(); 
	   	
	   	Thread.sleep(2000);
	   	
	    driver.findElement(By.xpath("//*[@id=\"add-edit-staff-dialog\"]/mat-dialog-content/div[2]/form/div[4]/div[1]/button/span[1]")).click();//emailId

	   	    
}
public void Add_user_Xuriti_Admin_InActive(String FN,String LN, String email, String MN) throws InterruptedException {
	
    //click on add user
	
    Thread.sleep(3000);
    
	driver.findElement(By.xpath("//*[@id=\"stafflist-page\"]/div/button")).click(); 	

	Thread.sleep(2000);
	
	driver.findElement(By.id("mat-input-4")).sendKeys(FN);//FirstName
	
    Thread.sleep(2000);
    
    driver.findElement(By.id("mat-input-5")).sendKeys(LN);//LastName 
    
    Thread.sleep(2000);
    
    driver.findElement(By.id("mat-input-6")).sendKeys(email);//Email 
    
    Thread.sleep(2000);
    
    driver.findElement(By.id("mat-input-7")).sendKeys(MN);//MN 
    
  //Select user type xuriti admin
	
   	Thread.sleep(3000);
   	    
   	driver.findElement(By.xpath("")).click(); 
   	
   	Thread.sleep(3000);
	    
   	driver.findElement(By.xpath("//*[@id=\"mat-option-10\"]/span")).click();
 
   	
   	//submit
   	
    Thread.sleep(2000);
   	
    driver.findElement(By.xpath("//*[@id=\"add-edit-staff-dialog\"]/mat-dialog-content/div[2]/form/div[4]/div[1]/button/span[1]")).click();//emailId

 	
}
public void Add_user_Xuriti_Staff(String FN,String LN, String email, String MN) throws InterruptedException {
	
	//click on add user
	
    Thread.sleep(3000);
    
	driver.findElement(By.xpath("//*[@id=\"stafflist-page\"]/div/button")).click(); 	

	Thread.sleep(2000);
	
	driver.findElement(By.id("mat-input-4")).sendKeys(FN);//FirstName
	
    Thread.sleep(2000);
    
    driver.findElement(By.id("mat-input-5")).sendKeys(LN);//LastName 
    
    Thread.sleep(2000);
    
    driver.findElement(By.id("mat-input-6")).sendKeys(email);//Email 
    
    Thread.sleep(2000);
    
    driver.findElement(By.id("mat-input-7")).sendKeys(MN);//MN 
       
//Select user type xuriti staff
	
   	Thread.sleep(3000);
   	    
   	driver.findElement(By.xpath("//*[@id=\"mat-select-value-9\"]/span")).click(); 
   	
   	Thread.sleep(3000);
	    
   	driver.findElement(By.xpath("")).click(); 
 
   	//Select user status Active
//	
//   	Thread.sleep(3000);
//   	    
//   	driver.findElement(By.xpath("//*[@id=\"mat-select-value-9\"]/span")).click(); 
//   	
//   	Thread.sleep(3000);
//	    
//   	driver.findElement(By.xpath("//*[@id=\"mat-option-12\"]/span")).click();  //active
//   	
   	//submit
   	
    Thread.sleep(2000);
   	
    driver.findElement(By.xpath("//*[@id=\"add-edit-staff-dialog\"]/mat-dialog-content/div[2]/form/div[4]/div[1]/button/span[1]")).click();//emailId

   	    
}	
public void Add_user_Xuriti_Staff_InActive(String FN,String LN, String email, String MN) throws InterruptedException {
	
	//click on add user
	
    Thread.sleep(3000);
    
	driver.findElement(By.xpath("//*[@id=\"stafflist-page\"]/div/button")).click(); 	

	Thread.sleep(2000);
	
	driver.findElement(By.id("mat-input-5")).sendKeys(FN);//FirstName
	
    Thread.sleep(2000);
    
    driver.findElement(By.id("mat-input-6")).sendKeys(LN);//LastName 
    
    Thread.sleep(2000);
    
    driver.findElement(By.id("mat-input-7")).sendKeys(email);//Email 
    
    Thread.sleep(2000);
    
    driver.findElement(By.id("mat-input-8")).sendKeys(MN);//MN 
       
//Select user type xuriti staff
	
    Thread.sleep(2000);
   	    
   	driver.findElement(By.xpath("//*[@id=\"mat-select-value-7\"]/span")).click(); 
   	
   	Thread.sleep(2000);
	    
   	driver.findElement(By.xpath("//*[@id=\"mat-option-11\"]/span")).click(); 
 
   	//Select user status InActive
	
   	Thread.sleep(2000);
   	    
   	driver.findElement(By.xpath("//*[@id=\"mat-select-value-9\"]/span")).click(); 
   	
   	Thread.sleep(2000);
	    
   	driver.findElement(By.xpath("//*[@id=\"mat-option-13\"]/span")).click();  //Inactive
   	
   	//submit
   	
   	Thread.sleep(2000);
   	
    driver.findElement(By.xpath("//*[@id=\"add-edit-staff-dialog\"]/mat-dialog-content/div[2]/form/div[4]/div[1]/button/span[1]")).click();//emailId

   	     
}
public void Add_user_Xuriti_CreditManager(String FN,String LN, String email, String MN) throws InterruptedException {
	
    //click on add user
	
    Thread.sleep(3000);
    
	driver.findElement(By.xpath("//*[@id=\"stafflist-page\"]/div/button")).click(); 	

	Thread.sleep(2000);
	
	driver.findElement(By.id("mat-input-4")).sendKeys(FN);//FirstName
	
    Thread.sleep(2000);
    
    driver.findElement(By.id("mat-input-5")).sendKeys(LN);//LastName 
    
    Thread.sleep(2000);
    
    driver.findElement(By.id("mat-input-6")).sendKeys(email);//Email 
    
    Thread.sleep(2000);
    
    driver.findElement(By.id("mat-input-7")).sendKeys(MN);//MN 
    
    //Select user type xuriti creditManager
	
   	Thread.sleep(3000);
   	    
   	driver.findElement(By.xpath("//*[@id=\"mat-select-8\"]/div/div[2]")).click(); 
   	
   	////*[@id="mat-select-8"]/div/div[2]
   	Thread.sleep(3000);
	    
   	driver.findElement(By.xpath("//*[@id=\"mat-option-15\"]/span")).click(); 
   	
   	Thread.sleep(2000);
   	
    driver.findElement(By.xpath("//*[@id=\"add-edit-staff-dialog\"]/mat-dialog-content/div[2]/form/div[4]/div[1]/button/span[1]")).click();//emailId  	    
}
public void Edit_user_Xuriti_Admin_Active_FN(String FN) throws InterruptedException {
	
    //click on Edit user
	
    Thread.sleep(3000);
    
	//driver.findElement(By.xpath("//*[@id=\"stafflist-page\"]/div/table/tbody/tr[2]/td[8]/button[1]/span[1]/mat-icon")).click(); 	

	driver.findElement(By.xpath("//*[@id=\"stafflist-page\"]/div/table/tbody/tr[1]/td[8]/button[1]/span[1]/mat-icon")).click();
	
	Thread.sleep(2000);
	
	driver.findElement(By.id("mat-input-4")).clear();//FirstName
	
	Thread.sleep(2000);
	
	driver.findElement(By.id("mat-input-4")).sendKeys(FN);//FirstName
	
    //submit
	
   	Thread.sleep(2000);
   	
   // driver.findElement(By.xpath("//*[@id=\"stafflist-page\"]/div/table/tbody/tr[1]/td[6]/button[1]")).click();//emailId   

   	driver.findElement(By.xpath("//*[@id=\"add-edit-staff-dialog\"]/mat-dialog-content/div[2]/form/div[4]/div[1]/button/span[1]")).click();
   	
    Thread.sleep(3000);
	
	if(driver.getPageSource().contains("User edited successfully.")){
		System.out.println("Mandatory msg displayed'User edited successfully.'");
		}else{
		System.out.println("Mandatory msg not displayed");
		}

	Thread.sleep(3000);

	if (driver.getPageSource().contains("Please enter first name")) {
		System.out.println("Mandatory error msg displayed'Please enter first name'");
	} else {
		System.out.println("Mandatory error msg not displayed");
	}
}
public void Edit_user_Xuriti_Admin_Active_LN(String LN) throws InterruptedException {
	
    //click on Edit user
	
    Thread.sleep(3000);
    
	driver.findElement(By.xpath("//*[@id=\"stafflist-page\"]/div/table/tbody/tr[2]/td[8]/button[1]/span[1]/mat-icon")).click(); 	
	
	
    Thread.sleep(2000);
	
	driver.findElement(By.id("mat-input-4")).clear();//LastName
	
    Thread.sleep(2000);
    
    driver.findElement(By.id("mat-input-4")).sendKeys(LN);//LastName 
    
    //submit
   	
   	Thread.sleep(2000);
   	
   	driver.findElement(By.xpath("//*[@id=\"add-edit-staff-dialog\"]/mat-dialog-content/div[2]/form/div[4]/div[1]/button/span[1]")).click();

    //   driver.findElement(By.xpath("//*[@id=\"add-edit-staff-dialog\"]/mat-dialog-content/div[2]/form/div[4]/div[1]/button/span[1]")).click();//emailId   

    Thread.sleep(3000);
	
  	if(driver.getPageSource().contains("User edited successfully.")){
  		System.out.println("Mandatory msg displayed'User edited successfully.'");
  		}else{
  		System.out.println("Mandatory msg not displayed");
  		}

  	Thread.sleep(3000);

  	if (driver.getPageSource().contains("Please enter last name")) {
  		System.out.println("Mandatory error msg displayed'Please enter last name'");
  	} else {
  		System.out.println("Mandatory error msg not displayed");
  	}
   	
}
public void Edit_user_Xuriti_Admin_Active_email( String email) throws InterruptedException {
	
    //click on Edit user
	
    Thread.sleep(3000);
    
	driver.findElement(By.xpath("//*[@id=\"stafflist-page\"]/div/table/tbody/tr[2]/td[8]/button[1]/span[1]/mat-icon")).click(); 	
	
	
	driver.findElement(By.id("mat-input-5")).clear();//email
    
    Thread.sleep(2000);
    
    driver.findElement(By.id("mat-input-5")).sendKeys(email);//Email 
    
    //submit
   	
   	Thread.sleep(3000);
	    
    driver.findElement(By.xpath("//*[@id=\"add-edit-staff-dialog\"]/mat-dialog-content/div[2]/form/div[4]/div[1]/button/span[1]")).click();//emailId   
  
    Thread.sleep(3000);
	
  	if(driver.getPageSource().contains("User edited successfully.")){
  		System.out.println("Mandatory msg displayed'User edited successfully.'");
  		}else{
  		System.out.println("Mandatory msg not displayed");
  		}

  	Thread.sleep(3000);

  	if (driver.getPageSource().contains("Please provide a valid email address")) {
  		System.out.println("Mandatory error msg displayed'Please provide a valid email address'");
  	} else {
  		System.out.println("Mandatory error msg not displayed");
  	}
}
public void Edit_user_Xuriti_Admin_Active_MN(String MN) throws InterruptedException {
	
    //click on Edit user
	
    Thread.sleep(3000);
    
	driver.findElement(By.xpath("//*[@id=\"stafflist-page\"]/div/table/tbody/tr[2]/td[8]/button[1]/span[1]/mat-icon")).click(); 	
	
    Thread.sleep(2000);
	
	driver.findElement(By.id("mat-input-6")).clear();//MN
    
    Thread.sleep(2000);
    
    driver.findElement(By.id("mat-input-6")).sendKeys(MN);//MN 
    
    //submit
    
   	Thread.sleep(2000);
   	
    driver.findElement(By.xpath("//*[@id=\"add-edit-staff-dialog\"]/mat-dialog-content/div[2]/form/div[4]/div[1]/button/span[1]")).click();//emailId   

   	if(driver.getPageSource().contains("User edited successfully.")){
  		System.out.println("Mandatory msg displayed'User edited successfully.'");
  		}else{
  		System.out.println("Mandatory msg not displayed");
  		}

  	Thread.sleep(3000);

  	if (driver.getPageSource().contains("Please enter valid mobile number")) {
  		System.out.println("Mandatory error msg displayed'Please enter valid mobile number'");
  	} else {
  		System.out.println("Mandatory error msg not displayed");
  	}

}
public void Edit_user_To_Xuriti_Admin() throws InterruptedException {
	
    //click on Edit user
	
    Thread.sleep(3000);
    
	driver.findElement(By.xpath("//*[@id=\"stafflist-page\"]/div/table/tbody/tr[2]/td[8]/button[1]/span[1]/mat-icon")).click(); 	
	
	//Select user type xuriti admin
	
   	Thread.sleep(3000);
   	    
   	driver.findElement(By.xpath("//*[@id=\"mat-select-value-9\"]")).click(); 
   	
   	Thread.sleep(3000);
	    
   	driver.findElement(By.xpath("//*[@id=\"mat-option-13\"]/span")).click(); 
 
   	//submit
   	
   	Thread.sleep(2000);
   	
   // driver.findElement(By.xpath("//*[@id=\"add-edit-staff-dialog\"]/mat-dialog-content/div[2]/form/div[4]/div[1]/button/span[1]")).click();//emailId   
}
public void Edit_user_To_Xuriti_staff() throws InterruptedException {
	
    //click on Edit user
	
    Thread.sleep(3000);
    
	driver.findElement(By.xpath("//*[@id=\"stafflist-page\"]/div/table/tbody/tr[2]/td[8]/button[1]/span[1]/mat-icon")).click(); 	
	
    //Select user type xuriti staff
	
   	Thread.sleep(3000);
   	    
   	driver.findElement(By.xpath("//*[@id=\"mat-select-value-9\"]")).click(); 
   	
   	Thread.sleep(3000);
	    
   	driver.findElement(By.xpath("//*[@id=\"mat-option-14\"]/span")).click(); 
   	//submit
   	
   	Thread.sleep(2000);
   	
    //driver.findElement(By.xpath("//*[@id=\"add-edit-staff-dialog\"]/mat-dialog-content/div[2]/form/div[4]/div[1]/button/span[1]")).click();//emailId   
}
public void Edit_user_To_Xuriti_creditManager() throws InterruptedException {
	
    //click on Edit user
	
    Thread.sleep(3000);
    
	driver.findElement(By.xpath("//*[@id=\"stafflist-page\"]/div/table/tbody/tr[2]/td[8]/button[1]/span[1]/mat-icon")).click(); 	
	
    //Select user type xuriti creditManager
	
   	Thread.sleep(3000);
   	    
   	driver.findElement(By.xpath("//*[@id=\"mat-select-value-7\"]/span")).click(); 
   	
   	Thread.sleep(3000);
	    
   	driver.findElement(By.xpath("//*[@id=\"mat-option-11\"]/span")).click(); 
   	//submit
   	
   	Thread.sleep(2000);
   	
    //driver.findElement(By.xpath("//*[@id=\"add-edit-staff-dialog\"]/mat-dialog-content/div[2]/form/div[4]/div[1]/button/span[1]")).click();//emailId   
}
public void Edit_user_To_Active() throws InterruptedException {
	
    //click on Edit user
	
    Thread.sleep(3000);
    
	driver.findElement(By.xpath("//*[@id=\"stafflist-page\"]/div/table/tbody/tr[2]/td[8]/button[1]/span[1]/mat-icon")).click(); 	
	
	//Select user status Active
	
   	Thread.sleep(3000);
   	    
   	driver.findElement(By.xpath("//*[@id=\"mat-select-value-9\"]/span")).click(); 
   	
   	Thread.sleep(3000);
	    
   	driver.findElement(By.xpath("//*[@id=\"mat-option-13\"]/span")).click();  //active
   	
   	//submit
   	
   	Thread.sleep(2000);
   	
    driver.findElement(By.xpath("//*[@id=\"add-edit-staff-dialog\"]/mat-dialog-content/div[2]/form/div[4]/div[1]/button/span[1]")).click();//emailId   
}
public void Edit_user_To_InActive() throws InterruptedException {
	
    //click on Edit user
	
    Thread.sleep(3000);
    
	driver.findElement(By.xpath("//*[@id=\"stafflist-page\"]/div/table/tbody/tr[2]/td[8]/button[1]/span[1]/mat-icon")).click(); 	
	
	//Select user status Active
	
   	Thread.sleep(3000);
   	    
   	driver.findElement(By.xpath("//*[@id=\"mat-select-value-9\"]/span")).click(); 
   	
   	Thread.sleep(3000);
	    
   	driver.findElement(By.xpath("//*[@id=\"mat-option-13\"]/span")).click();  //Inactive
   	
   	//submit
   	
   	Thread.sleep(2000);
   	
    driver.findElement(By.xpath("//*[@id=\"add-edit-staff-dialog\"]/mat-dialog-content/div[2]/form/div[4]/div[1]/button/span[1]")).click();//emailId   
}
public void Delete_User() throws InterruptedException {
	
    //click on Delete user
	
    Thread.sleep(3000);
    
	driver.findElement(By.xpath("//*[@id=\"stafflist-page\"]/div/table/tbody/tr[1]/td[6]/button[3]")).click(); 	
	
	//confirm
	
    Thread.sleep(3000);
    
	driver.findElement(By.xpath("//*[@id=\"dialogconfirm-page\"]/div/div[2]/button[1]/span[1]")).click(); 
}
public void Resend_Invite() throws InterruptedException {
	
    //click on Resend_Invite
	
    Thread.sleep(3000);
    
	driver.findElement(By.xpath("//*[@id=\"stafflist-page\"]/div/table/tbody/tr[2]/td[8]/button[2]/span[1]/mat-icon")).click(); 	
	
    Thread.sleep(3000);
	
	if(driver.getPageSource().contains("A link has been sent, Please Set password by clicking link send on your email id")){
		System.out.println("Mandatory msg displayed'A link has been sent, Please Set password by clicking link send on your email id'");
		}else{
		System.out.println("Mandatory msg not displayed");
		
		}
}
public void Items_per_page_25() throws InterruptedException {
	//click on arrow
	   
	   Thread.sleep(2000);
	   
	   driver.findElement(By.xpath("//*[@id=\"mat-select-4\"]/div/div[2]")).click();
	
     //click on 25
	   
	   Thread.sleep(2000);
	   
	   driver.findElement(By.xpath("//*[@id=\"mat-option-8\"]/span")).click();
	 	   
}
public void Items_per_page_50() throws InterruptedException {
	//click on arrow
	   
	   Thread.sleep(2000);
	   
	   driver.findElement(By.xpath("//*[@id=\"mat-select-4\"]/div/div[2]")).click();
	   
     //click on 50
	   
	   Thread.sleep(2000);
	   
	   driver.findElement(By.xpath("//*[@id=\"mat-option-9\"]/span")).click();	   
}
public void Next_Page_click() throws InterruptedException {
	//click on arrow
	   
	   Thread.sleep(5000);
	   //driver.findElement(By.xpath("//*[@id=\"stafflist-page\"]/div/mat-paginator/div/div/div[2]/button[3]/span[1]/svg")).click();
	   
	   driver.findElement(By.xpath("//*[@id=\"stafflist-page\"]/div/mat-paginator/div/div/div[2]/button[3]/span[1]/svg")).click();


	   //driver.findElement(By.xpath("//*[@id="stafflist-page"]/div/mat-paginator/div/div/div[2]/button[3]/span[1]/svg")).click();
	  // driver.findElement(By.xpath("//*[@id="stafflist-page"]/div/mat-paginator/div/div/div[2]/button[3]/span[1]/svg")).click();	   
}
}
