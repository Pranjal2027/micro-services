package com.Xuriti.admin_panel_main;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

public class Invoices {
WebDriver driver;
	
	
public Invoices  (WebDriver driver) throws InterruptedException {
		this.driver = driver;
		
		//Click on Invoices
		 
		Thread.sleep(3000);
				
       // driver.findElement(By.xpath("/html/body/app-root/app-companylist/app-layout/mat-sidenav-container/mat-sidenav/div/app-sidebar/div/div/div[3]/mat-nav-list/mat-list-item[1]/span/span[2]")).click();    
		  driver.findElement(By.xpath("/html/body/app-root/app-dashboard/app-layout/mat-sidenav-container/mat-sidenav/div/app-sidebar/div/div/div[3]/mat-nav-list/mat-list-item[2]/span/mat-icon")).click(); 
        //click on edit invoices
        
        Thread.sleep(3000);
    		
     driver.findElement(By.xpath("//*[@id=\"buyerinvoices-page\"]/div/table/tbody/tr[5]/td[11]/button[1]/span[1]/mat-icon")).click(); 
    	  
}
public void Edit_Invoice_number(String IN) throws InterruptedException {
	
		 
   		//Edit 
	
	    Thread.sleep(2000);
    
        driver.findElement(By.id("//*[@id=\"invoicesdetails-page\"]/div/mat-card/mat-card-content/div/form/div[1]/div[1]/mat-form-field[1]/div/div[1]")).clear();//Invoice_number 
		
	    Thread.sleep(2000);
	    
	    driver.findElement(By.id("//*[@id=\"invoicesdetails-page\"]/div/mat-card/mat-card-content/div/form/div[1]/div[1]/mat-form-field[1]/div/div[1]")).sendKeys(IN);//Invoice_number 
	    
	  //Submit
	    
	    driver.findElement(By.xpath("//*[@id=\"invoicesdetails-page\"]/div/mat-card/mat-card-content/div/form/div[6]/button[1]/span[1]")).click(); //admin
	 
	    Thread.sleep(3000);
		
		if(driver.getPageSource().contains("Invoice edited successfully.")){
			System.out.println("Mandatory msg displayed'Invoice edited successfully.'");
			}else{
			System.out.println("Mandatory msg not displayed");
			}	    	
}
public void Edit_Invoice_Date(String ID) throws InterruptedException {
	
	    Thread.sleep(2000);
	
	    driver.findElement(By.id("mat-input-7")).clear();//INVOICE_Date
	    
	    Thread.sleep(5000);
	    
	   // driver.findElement(By.id("//*[@id=\"invoicesdetails-page\"]/div/mat-card/mat-card-content/div/form/div[1]/div[1]/mat-form-field[2]/div/div[1]/div[3]")).sendKeys(ID);//INVOICE_Date 
	    
	  //Submit
	    
	    driver.findElement(By.xpath("//*[@id=\"invoicesdetails-page\"]/div/mat-card/mat-card-content/div/form/div[6]/button[1]/span[1]")).click(); //admin
		 
		    Thread.sleep(3000);
			
			if(driver.getPageSource().contains("Invoice edited successfully.")){
				System.out.println("Mandatory msg displayed'Invoice edited successfully.'");
				}else{
				System.out.println("Mandatory msg not displayed");
				}
	    	
}
public void Outstanding_Amount(String OD) throws InterruptedException {
	
		
	   //Edit user
		
	   Thread.sleep(3000);
	    
	    driver.findElement(By.id("//*[@id=\"invoicesdetails-page\"]/div/mat-card/mat-card-content/div/form/div[1]/div[1]/mat-form-field[3]/div/div[1]")).clear();//Outstanding_Amount
	    
	    driver.findElement(By.id("//*[@id=\"invoicesdetails-page\"]/div/mat-card/mat-card-content/div/form/div[1]/div[1]/mat-form-field[3]/div/div[1]")).sendKeys(OD);//Outstanding_Amount 
	    
	  //Submit
	    
	    driver.findElement(By.xpath("//*[@id=\"invoicesdetails-page\"]/div/mat-card/mat-card-content/div/form/div[5]/button[1]")).click(); //admin
		 
		    Thread.sleep(3000);
			
			if(driver.getPageSource().contains("Invoice edited successfully.")){
				System.out.println("Mandatory msg displayed'Invoice edited successfully.'");
				}else{
				System.out.println("Mandatory msg not displayed");
				}    	
}
public void Extra_Credit_Allowed_NO() throws InterruptedException {
	
		
	//credit limit 1st NO(click on NO)
	 
	Thread.sleep(2000);
		
  	 driver.findElement(By.xpath(" //*[@id=\"mat-select-12\"]/div/div[2]")).click(); //Extra_Credit not _Allowed
  	
	  //NO
	    
  	driver.findElement(By.xpath("//*[@id=\"mat-option-29\"]/span")).click(); 
  	
  	//submit
  	
  	driver.findElement(By.xpath("//*[@id=\"invoicesdetails-page\"]/div/mat-card/mat-card-content/div/form/div[6]/button[1]/span[1]")).click(); //admin

		 
		    Thread.sleep(3000);
			
			if(driver.getPageSource().contains("Invoice edited successfully.")){
				System.out.println("Mandatory msg displayed'Invoice edited successfully.'");
				}else{
				System.out.println("Mandatory msg not displayed");
				}    	
}
public void Extra_Credit_Allowed_YES() throws InterruptedException {
	
		
	//credit limit 1st NO(click on NO)
	 
	Thread.sleep(2000);
		
  	 driver.findElement(By.xpath("//*[@id=\"mat-select-12\"]/div/div[2]")).click(); //Extra_Credit not _Allowed
  	
      //select YES
 
  	  Thread.sleep(2000);
  		
     driver.findElement(By.xpath("//*[@id=\"mat-option-28\"]/span")).click(); //Extra_Credit_Allowed
		
	  //Submit
	    
   	driver.findElement(By.xpath("//*[@id=\"invoicesdetails-page\"]/div/mat-card/mat-card-content/div/form/div[6]/button[1]/span[1]")).click(); //admin
		 
		    Thread.sleep(3000);
			
			if(driver.getPageSource().contains("Invoice edited successfully.")){
				System.out.println("Mandatory msg displayed'Invoice edited successfully.'");
				}else{
				System.out.println("Mandatory msg not displayed");
				}    	
}
public void Invoice_due_date(String DD) throws InterruptedException {
	
		
	   //Edit user
		
	   Thread.sleep(3000);
	    
	 //   driver.findElement(By.id("mat-input-9")).clear();//Invoice_due_date
	    
	    driver.findElement(By.id("mat-input-9")).sendKeys(DD);//Invoice_due_date 
	    
	   //Submit
	    
	    driver.findElement(By.xpath("//*[@id=\"invoicesdetails-page\"]/div/mat-card/mat-card-content/div/form/div[6]/button[1]/span[1]")).click(); //admin
		 
		    Thread.sleep(3000);
			
			if(driver.getPageSource().contains("Invoice edited successfully.")){
				System.out.println("Mandatory msg displayed'Invoice edited successfully.'");
				}else{
				System.out.println("Mandatory msg not displayed");
				}    	
}
public void Invoice_Amount(String IA) throws InterruptedException {
	
		
	   //Edit user
	 driver.findElement(By.id("mat-input-10")).clear();
	   Thread.sleep(3000);
	   driver.findElement(By.xpath("mat-input-10")).click(); 
	   // driver.findElement(By.id("//*[@id="invoicesdetails-page"]/div/mat-card/mat-card-content/div/form/div[1]/div[2]/mat-form-field[2]/div/div[1]/div[3]")).click();//Invoice_due_date
	    
	 //  driver.findElement(By.id("//*[@id=\"invoicesdetails-page\"]/div/mat-card/mat-card-content/div/form/div[1]/div[2]/mat-form-field[2]/div/div[1]/div[3]")).sendKeys();//Invoice_due_date 
	    
	   //Submit
	   Thread.sleep(3000);
driver.findElement(By.xpath("//*[@id=\"invoicesdetails-page\"]/div/mat-card/mat-card-content/div/form/div[5]/button[1]")).click(); //admin
		 
		    Thread.sleep(3000);
			
			if(driver.getPageSource().contains("Invoice edited successfully.")){
				System.out.println("Mandatory msg displayed'Invoice edited successfully.'");
				}else{
				System.out.println("Mandatory msg not displayed");
				}    	
}
public void Invoice_Status_Pending() throws InterruptedException {
	
		     //Invoice_Status
	 
		Thread.sleep(2000);
			
		   driver.findElement(By.xpath("//*[@id=\"mat-select-14\"]/div/div[2]")).click(); 
	  	
		 //Invoice_Status_Pending
			 
			Thread.sleep(2000);
					
			driver.findElement(By.xpath("//*[@id=\"mat-option-30\"]/span")).click(); 
			  
			
	   //Submit
	    
	  	driver.findElement(By.xpath("//*[@id=\"invoicesdetails-page\"]/div/mat-card/mat-card-content/div/form/div[6]/button[1]/span[1]")).click(); //admin
		 
		    Thread.sleep(3000);
			
			if(driver.getPageSource().contains("Invoice edited successfully.")){
				System.out.println("Mandatory msg displayed'Invoice edited successfully.'");
				}else{
				System.out.println("Mandatory msg not displayed");
				}    	
}
public void Invoice_Status_Confirmed() throws InterruptedException {
	
		
	//Invoice_Status
	 
	Thread.sleep(2000);
				
	   driver.findElement(By.xpath("//*[@id=\"mat-select-14\"]/div/div[2]")).click(); 
		  	
	
	//Invoice_Status_confirmed 
	 
	Thread.sleep(2000);
			
	driver.findElement(By.xpath("//*[@id=\"mat-option-31\"]/span")).click(); 
	  	
	   //Submit
	    
  	driver.findElement(By.xpath("//*[@id=\"invoicesdetails-page\"]/div/mat-card/mat-card-content/div/form/div[6]/button[1]/span[1]")).click(); //admin
		 
		    Thread.sleep(3000);
			
			if(driver.getPageSource().contains("Invoice edited successfully.")){
				System.out.println("Mandatory msg displayed'Invoice edited successfully.'");
				}else{
				System.out.println("Mandatory msg not displayed");
				}    	
}
public void Invoice_Status_Rejected() throws InterruptedException {
	
		
	//Invoice_Status
	 
	Thread.sleep(2000);
				
	   driver.findElement(By.xpath("//*[@id=\"mat-select-14\"]/div/div[2]")).click(); 
		  	
	
	//Invoice_Status_Rejected
	 
	Thread.sleep(2000);
			
	driver.findElement(By.xpath("//*[@id=\"mat-option-32\"]/span")).click(); 
	  	
	   //Submit
	    
  	driver.findElement(By.xpath("//*[@id=\"invoicesdetails-page\"]/div/mat-card/mat-card-content/div/form/div[6]/button[1]/span[1]")).click(); //admin
		 
		    Thread.sleep(3000);
			
			if(driver.getPageSource().contains("Invoice edited successfully.")){
				System.out.println("Mandatory msg displayed'Invoice edited successfully.'");
				}else{
				System.out.println("Mandatory msg not displayed");
				}    	
}
public void Invoice_Status_Draft() throws InterruptedException {
	
		//Invoice_Status
	 
	Thread.sleep(2000);
				
	   driver.findElement(By.xpath("//*[@id=\"mat-select-14\"]/div/div[2]")).click(); 
		  	
	
	//Invoice_Status_draft 
	 
	Thread.sleep(2000);
			
	driver.findElement(By.xpath("//*[@id=\"mat-option-30\"]/span")).click(); 
	  	
	   //Submit
	    
	driver.findElement(By.xpath("//*[@id=\"invoicesdetails-page\"]/div/mat-card/mat-card-content/div/form/div[6]/button[1]/span[1]")).click(); //admin
		 
		    Thread.sleep(3000);
			
			if(driver.getPageSource().contains("Invoice edited successfully.")){
				System.out.println("Mandatory msg displayed'Invoice edited successfully.'");
				}else{
				System.out.println("Mandatory msg not displayed");
				}    	
}
public void Invoice_Status_Paid() throws InterruptedException {
	
	//Invoice_Status
	 
	Thread.sleep(2000);
				
	   driver.findElement(By.xpath("//*[@id=\"mat-select-14\"]/div/div[2]")).click(); 
		  	
	
	//Invoice_Status_Paid 
	 
	Thread.sleep(2000);
			
	driver.findElement(By.xpath("//*[@id=\"mat-option-31\"]/span")).click(); 
	  	
	   //Submit
	    
	driver.findElement(By.xpath("//*[@id=\"invoicesdetails-page\"]/div/mat-card/mat-card-content/div/form/div[6]/button[1]/span[1]")).click(); //admin
		 
		    Thread.sleep(3000);
			
			if(driver.getPageSource().contains("Invoice edited successfully.")){
				System.out.println("Mandatory msg displayed'Invoice edited successfully.'");
				}else{
				System.out.println("Mandatory msg not displayed");
				}    	
}
public void Invoice_Status_Duplicate() throws InterruptedException {

	//Invoice_Status
	 
	Thread.sleep(2000);
				
	   driver.findElement(By.xpath("//*[@id=\"mat-select-14\"]/div/div[2]")).click(); 
		  		
	//Invoice_Status_Duplicate 
	 
	Thread.sleep(2000);
			
	driver.findElement(By.xpath("//*[@id=\"mat-option-32\"]/span")).click(); 
	  	
	   //Submit
	    
	driver.findElement(By.xpath("//*[@id=\"invoicesdetails-page\"]/div/mat-card/mat-card-content/div/form/div[6]/button[1]/span[1]")).click(); //admin
		 
		    Thread.sleep(3000);
			
			if(driver.getPageSource().contains("Invoice edited successfully.")){
				System.out.println("Mandatory msg displayed'Invoice edited successfully.'");
				}else{
				System.out.println("Mandatory msg not displayed");
				}    	
}
public void Invoice_Status_Seller_Absent() throws InterruptedException {
	
	//Invoice_Status
	 
	Thread.sleep(2000);
				
	   driver.findElement(By.xpath("//*[@id=\"mat-select-14\"]/div/div[2]")).click(); 
		  		
	//Invoice_Status_Seller_Absent
	 
	Thread.sleep(2000);
			
	driver.findElement(By.xpath("//*[@id=\"mat-option-33\"]/span")).click(); 
	  	
	   //Submit
	    
	driver.findElement(By.xpath("//*[@id=\"invoicesdetails-page\"]/div/mat-card/mat-card-content/div/form/div[6]/button[1]/span[1]")).click(); //admin
		 
		    Thread.sleep(3000);
			
			if(driver.getPageSource().contains("Invoice edited successfully.")){
				System.out.println("Mandatory msg displayed'Invoice edited successfully.'");
				}else{
				System.out.println("Mandatory msg not displayed");
				}    	
}
public void Invoice_Status_Buyer_Absent() throws InterruptedException {
	
	//Invoice_Status
	 
	Thread.sleep(2000);
				
   driver.findElement(By.xpath("//*[@id=\"mat-select-14\"]/div/div[2]")).click(); 
		  		
	//Invoice_Status_Buyer_Absent
	 
	Thread.sleep(2000);
			
	driver.findElement(By.xpath("//*[@id=\"mat-option-37\"]/span")).click(); 
	  	
	   //Submit
	    
	driver.findElement(By.xpath("//*[@id=\"invoicesdetails-page\"]/div/mat-card/mat-card-content/div/form/div[6]/button[1]/span[1]")).click(); //admin
		 
		    Thread.sleep(3000);
			
			if(driver.getPageSource().contains("Invoice edited successfully.")){
				System.out.println("Mandatory msg displayed'Invoice edited successfully.'");
				}else{
				System.out.println("Mandatory msg not displayed");
				}    	
}
public void edit_seller_details_GST_NO(String gst) throws InterruptedException {
	
	//Gst number
	 
	Thread.sleep(3000);
				
	   driver.findElement(By.xpath("//*[@id=\"mat-select-14\"]/div/div[2]")).click(); 
		  		
 //Gst number
   
	Thread.sleep(2000);
			
	driver.findElement(By.xpath("//*[@id=\"mat-input-13\"]")).sendKeys(gst); 
	  	
	   //Submit
	    
	driver.findElement(By.xpath("//*[@id=\"invoicesdetails-page\"]/div/mat-card/mat-card-content/div/form/div[5]/button[1]")).click(); //admin
		 
		    Thread.sleep(3000);
			
			if(driver.getPageSource().contains("Invoice edited successfully.")){
				System.out.println("Mandatory msg displayed'Invoice edited successfully.'");
				}else{
				System.out.println("Mandatory msg not displayed");
				}    	
}
public void edit_seller_details_Mob_NO(String MN) throws InterruptedException {
	
	//Invoice_Status
	 
	Thread.sleep(2000);
				
   driver.findElement(By.xpath("//*[@id=\"mat-input-14\"]")).clear(); 
		  		
	//Invoice_Status_Buyer_Absent
	 
	Thread.sleep(2000);
			
	driver.findElement(By.xpath("//*[@id=\"mat-input-14\"]")).sendKeys(MN); 
	  	
	   //Submit
	    
	driver.findElement(By.xpath("//*[@id=\"invoicesdetails-page\"]/div/mat-card/mat-card-content/div/form/div[5]/button[1]")).click(); //admin
		 
		    Thread.sleep(3000);
			
			if(driver.getPageSource().contains("Invoice edited successfully.")){
				System.out.println("Mandatory msg displayed'Invoice edited successfully.'");
				}else{
				System.out.println("Mandatory msg not displayed");
				}    	
}
public void edit_seller_details_Name(String Name) throws InterruptedException {
	
	//Invoice_Status
	 
	Thread.sleep(2000);
				
   driver.findElement(By.xpath("//*[@id=\"mat-input-15\"]")).clear(); 
		  		
	//Invoice_Status_Buyer_Absent
	 
	Thread.sleep(2000);
			
	driver.findElement(By.xpath("//*[@id=\"mat-input-15\"]")).sendKeys(Name); 
	  	
	   //Submit
	    
	driver.findElement(By.xpath("//*[@id=\"invoicesdetails-page\"]/div/mat-card/mat-card-content/div/form/div[5]/button[1]")).click(); //admin
		 
		    Thread.sleep(3000);
			
			if(driver.getPageSource().contains("Invoice edited successfully.")){
				System.out.println("Mandatory msg displayed'Invoice edited successfully.'");
				}else{
				System.out.println("Mandatory msg not displayed");
				}    	
}
public void edit_seller_details_Email_add(String email) throws InterruptedException {
	
	//Invoice_Status
	 
	Thread.sleep(2000);
				
   driver.findElement(By.xpath("//*[@id=\"mat-input-16\"]")).clear(); 
		  		
	//Invoice_Status_Buyer_Absent
	 
	Thread.sleep(2000);
			
	driver.findElement(By.xpath("//*[@id=\"mat-input-16\"]")).sendKeys(email); 
	  	
	   //Submit
	    
driver.findElement(By.xpath("//*[@id=\"invoicesdetails-page\"]/div/mat-card/mat-card-content/div/form/div[5]/button[1]")).click(); //admin
		 
		    Thread.sleep(3000);
			
			if(driver.getPageSource().contains("Invoice edited successfully.")){
				System.out.println("Mandatory msg displayed'Invoice edited successfully.'");
				}else{
				System.out.println("Mandatory msg not displayed");
				}    	
}
public void edit_seller_details_Status(String status) throws InterruptedException {
	
	//Invoice_Status
	 
	Thread.sleep(2000);
				
   driver.findElement(By.xpath("//*[@id=\"mat-input-17\"]")).clear(); 
		  		
	//Invoice_Status_Buyer_Absent
	 
	Thread.sleep(2000);
			
	driver.findElement(By.xpath("//*[@id=\"mat-input-17\"]")).sendKeys(status); 
	  	
	   //Submit
	    
	driver.findElement(By.xpath("//*[@id=\"invoicesdetails-page\"]/div/mat-card/mat-card-content/div/form/div[5]/button[1]")).click(); //admin
		 
		    Thread.sleep(3000);
			
			if(driver.getPageSource().contains("Invoice edited successfully.")){
				System.out.println("Mandatory msg displayed'Invoice edited successfully.'");
				}else{
				System.out.println("Mandatory msg not displayed");
				}    	
}
public void Items_Per_page_20() throws InterruptedException {
	//click on arrow
	   
	  Thread.sleep(5000);
	   
	   driver.findElement(By.xpath("//*[@id=\"mat-select-10\"]/div")).click();
	   
	  // driver.findElement(By.xpath("//*[@id=\"mat-select-24\"]/div/div[2]")).click();
	   
	   //  Click On Invoice
	  
	     
	   
	  // driver.findElement(By.xpath("/html/body/app-root/app-invoicesdetails/app-layout/mat-sidenav-container/mat-sidenav/div/app-sidebar/div/div/div[3]/mat-nav-list/mat-list-item[1]/span/span[2]/a")).click();
	   //click on invoice icon
	  //driver.findElement(By.xpath("/html/body/app-root/app-buyerinvoices/app-layout/mat-sidenav-container/mat-sidenav/div/app-sidebar/div/div/div[3]/mat-nav-list/mat-list-item[1]/span/span[2]/a")).click();
	  
	  
	  //click on invoice 
	  
	 // driver.findElement(By.xpath("/html/body/app-root/app-dashboard/app-layout/mat-sidenav-container/mat-sidenav/div/app-sidebar/div/div/div[3]/mat-nav-list/mat-list-item[2]/span/span[2]")).click();
	 //  Thread.sleep(2000);
	   
	   
	  // JavascriptExecutor js = (JavascriptExecutor) driver;
		//  js.executeScript("window.scrollBy(0,350)", "");
		   
		//  Thread.sleep(2000);
		
	   
	   
	
     //click on 20
	   
	   Thread.sleep(2000);
	   
	   driver.findElement(By.xpath("//*[@id=\"mat-option-26\"]/span")).click();
	 
	   
}
public void Items_Per_page_50() throws InterruptedException {
	//click on arrow
	   
	   Thread.sleep(2000);
	   
	   driver.findElement(By.xpath("//*[@id=\"mat-select-10\"]/div")).click();
	   
	   //driver.findElement(By.xpath("//*[@id=\"mat-select-24\"]/div")).click();
     //click on 50
	   
	   Thread.sleep(2000);
	   
	   driver.findElement(By.xpath("//*[@id=\"mat-option-27\"]/span")).click();	   
}
public void Next_Page_click() throws InterruptedException {
	//click on invoices
	driver.findElement(By.xpath("/html/body/app-root/app-dashboard/app-layout/mat-sidenav-container/mat-sidenav/div/app-sidebar/div/div/div[3]/mat-nav-list/mat-list-item[2]/span/span[2]/a")).click();
	
	
	//click on arrow
	   
	   Thread.sleep(2000);
	   
	   driver.findElement(By.xpath("//*[@id=\"buyerinvoices-page\"]/div/mat-paginator/div/div/div[2]/button[3]/span[1]/svg")).click();
	   	   
}
}


